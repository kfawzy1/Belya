<?php

return [
    'site_title' => 'Belya',
    'bookings_card_title' => 'Bookings',
    'earnings_card_title' => 'Earnings',
    'providers_card_title' => 'Providers',
    'customers_card_title' => 'Customers',
];
