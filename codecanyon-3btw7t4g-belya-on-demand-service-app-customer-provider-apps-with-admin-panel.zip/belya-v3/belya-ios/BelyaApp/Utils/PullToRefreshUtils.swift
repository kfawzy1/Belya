//
//  PullToRefreshUtils.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 13/11/2021.
//

import UIKit

class RefreshUtils {

    static let loaderColor = UIColor(named: "contentPrimary")

    static func addPullToRefresh(controller: UIViewController, tableView: UITableView ,refreshAction: Selector) {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = loaderColor
        refreshControl.addTarget(controller, action: refreshAction, for: UIControl.Event.valueChanged)
        tableView.refreshControl = refreshControl
    }

    static func addPullToRefresh(view: UIView, tableView: UITableView ,refreshAction: Selector) {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = loaderColor
        refreshControl.addTarget(view, action: refreshAction, for: UIControl.Event.valueChanged)
        tableView.refreshControl = refreshControl
    }

    static func addPullToRefresh(controller: UIViewController, scrollView: UIScrollView ,refreshAction: Selector) {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = loaderColor
        refreshControl.addTarget(controller, action: refreshAction, for: UIControl.Event.valueChanged)
        scrollView.refreshControl = refreshControl
    }

    static func addPullToRefresh(controller: UIViewController, collectionView: UICollectionView ,refreshAction: Selector) {
           let refreshControl = UIRefreshControl()
           refreshControl.tintColor = loaderColor
           refreshControl.addTarget(controller, action: refreshAction, for: UIControl.Event.valueChanged)
           collectionView.refreshControl = refreshControl
       }
}
