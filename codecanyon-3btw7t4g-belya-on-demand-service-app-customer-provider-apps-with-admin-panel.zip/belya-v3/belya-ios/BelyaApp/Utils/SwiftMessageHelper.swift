//
//  SwiftMessageHelper.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 09/09/2021.
//

import SwiftMessages

class SwiftMessageHelper {

    static func showMessage(theme: Theme = .success, message: String) {
        let view = MessageView.viewFromNib(layout: .cardView)
        // Theme message elements with the warning style.
        view.configureTheme(theme)
        // Add a drop shadow.
        view.configureDropShadow()

        // Set message title, body, and icon. Here, we're overriding the default warning
        // image with an emoji character.
        let trimmedMessage = (message.count > 250) ? String(message.prefix(250)) : message
        view.configureContent(body: trimmedMessage)

        // Increase the external margin around the card. In general, the effect of this setting
        // depends on how the given layout is constrained to the layout margins.
        view.layoutMarginAdditions = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)

        // no need for them now
        view.titleLabel?.isHidden = true
        view.button?.isHidden = true
        // Show the message.
        SwiftMessages.show(view: view)
    }

    static func showBottomSheetView(view: UIView) {
        var config = SwiftMessages.defaultConfig
        config.duration = SwiftMessages.Duration.forever
        config.presentationStyle = .bottom
        config.presentationContext = .window(windowLevel: .alert)
        config.dimMode = .gray(interactive: true)
        SwiftMessages.show(config: config, view: view)
    }

    static func dismissAllViews() {
        SwiftMessages.hideAll()
    }
}
