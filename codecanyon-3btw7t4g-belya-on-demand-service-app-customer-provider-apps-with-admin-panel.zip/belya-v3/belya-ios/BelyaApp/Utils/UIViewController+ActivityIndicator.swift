//
//  UIViewController+ActivityIndicator.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 14/09/2021.
//

import UIKit
import NVActivityIndicatorView

extension UIViewController: NVActivityIndicatorViewable {
    func showActivityIndicator() {
        DispatchQueue.main.async {
            let size = CGSize(width: 30, height: 30)
            NVActivityIndicatorView.DEFAULT_COLOR = .black
            self.startAnimating(size, message: "", type: NVActivityIndicatorType.ballClipRotate)
        }
    }

    func stopActivityIndicator() {
        DispatchQueue.main.async {
            self.stopAnimating()
        }
    }
}
