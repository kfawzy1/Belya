//
//  BelyaButton.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 29/10/2021.
//

import Foundation
import UIKit

class BelyaButton: UIButton {

    override open var isHighlighted: Bool {
        didSet {
            backgroundColor = isHighlighted ?
            UIColor(named: "HighlightedButton") ??
                .white : UIColor(named: "contentPrimary") ?? .black
            titleLabel?.textColor = UIColor(named: "primaryB")
        }
    }

    override var buttonType: UIButton.ButtonType {
        return .custom
    }
 

    override func awakeFromNib() {
        super.awakeFromNib()
        if #available(iOS 15.0, *) {
            configuration = .plain()
        }
        titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)

        backgroundColor = UIColor(named: "contentPrimary") ?? .black
        setTitleColor(UIColor(named: "primaryB"), for: .normal)
        setTitleColor(UIColor(named: "primaryB"), for: .highlighted)
        addTarget(self, action: #selector(self.pressed), for: [.touchDown])
        addTarget(self, action: #selector(self.released), for: [.touchDragExit, .touchUpInside, .touchUpOutside, .touchCancel])
    }
    
    @objc func pressed() { }

    @objc func released() { }

}
