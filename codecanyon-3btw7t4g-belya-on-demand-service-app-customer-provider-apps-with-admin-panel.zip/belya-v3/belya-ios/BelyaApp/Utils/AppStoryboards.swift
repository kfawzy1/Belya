//
//  AppStoryboards.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 15/09/2021.
//

import Foundation
import UIKit

enum AppStoryboard: String {
    case ProviderHome
    case CustomerHome
    case Main
    
    var instance: UIStoryboard {
        return UIStoryboard(name: self.rawValue, bundle: Bundle.main)
    }
    
    func viewController<T: UIViewController>(viewControllerClass: T.Type,
                                             function: String = #function,
                                             line: Int = #line,
                                             file: String = #file) -> T {
        
        let storyboardID = (viewControllerClass as UIViewController.Type).storyboardID
        
        guard let scene = instance.instantiateViewController(withIdentifier: storyboardID) as? T else {
            fatalError("ViewController with identifier \(storyboardID), not found in \(self.rawValue) Storyboard.\nFile : \(file) \nLine Number : \(line) \nFunction : \(function)")
        }
        return scene
    }
    
    func initialViewController() -> UIViewController? {
        return instance.instantiateInitialViewController()
    }
}

extension UIViewController {
    // Not using static as it wont be possible to override to provide custom storyboardID then
    class var storyboardID: String {
        return "\(self)"
    }

    static func instantiate(fromAppStoryboard appStoryboard: AppStoryboard) -> Self {
        return appStoryboard.viewController(viewControllerClass: self)
    }

    func push<T: UIViewController>(viewControllerClass: T.Type, inAppStoryboard appStoryboard: AppStoryboard){
        let vc = viewControllerClass.instantiate(fromAppStoryboard: appStoryboard)
        navigationController?.pushViewController(vc, animated: true)
    }
}

// Usage
//
//let greenScene = GreenVC.instantiate(fromAppStoryboard: .Main)
//
//let greenScene = AppStoryboard.Main.viewController(viewControllerClass: GreenVC.self)
//
//let greenScene = AppStoryboard.Main.instance.instantiateViewController(withIdentifier: GreenVC.storyboardID)
