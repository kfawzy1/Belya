//
//  UserDefaultsExtension.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 14/09/2021.
//

import Foundation

enum SavedKeys: String {
    case user
    case bearerToken
    case configs
    case firstTimeCallGetConfigs
    case selectedAddress
    case recentAddresses
    case appTheme
}

enum AppTarget: String {
    case Belya
    case BelyaProvider = "Belya Provider"
}

extension UserDefaults {
    
    var appTarget: AppTarget {
        get {
            return AppTarget(rawValue: Bundle.main.infoDictionary?["CFBundleName"] as? String ?? "") ?? .Belya
        }
    }

    var user: User? {
        get {
            guard let data = UserDefaults.standard.data(forKey: SavedKeys.user.rawValue) else {
                return nil
            }
            let decoder = JSONDecoder()
            let obj = try? decoder.decode(User.self, from: data)
            return obj
        } set {
            let encoder = JSONEncoder()
            let data = try? encoder.encode(newValue)
            UserDefaults.standard.set(data, forKey: SavedKeys.user.rawValue)
        }
    }

    var configs: Configs? {
        get {
            guard let data = UserDefaults.standard.data(forKey: SavedKeys.configs.rawValue) else {
                return nil
            }
            let decoder = JSONDecoder()
            let obj = try? decoder.decode(Configs.self, from: data)
            return obj
        } set {
            let encoder = JSONEncoder()
            let data = try? encoder.encode(newValue)
            UserDefaults.standard.set(data, forKey: SavedKeys.configs.rawValue)
        }
    }

    var token: String? {
        get {
            return string(forKey: SavedKeys.bearerToken.rawValue)
            
        } set {
            set(newValue, forKey: SavedKeys.bearerToken.rawValue)
        }
    }

    var selectedAddress: AddressModel? {
        get {
            guard let data = UserDefaults.standard.data(forKey: SavedKeys.selectedAddress.rawValue) else {
                return nil
            }
            let decoder = JSONDecoder()
            let obj = try? decoder.decode(AddressModel.self, from: data)
            return obj
        } set {
            let encoder = JSONEncoder()
            let data = try? encoder.encode(newValue)
            UserDefaults.standard.set(data, forKey: SavedKeys.selectedAddress.rawValue)
        }
    }

    var theme: AppTheme {
        get {
//            register(defaults: [SavedKeys.appTheme.rawValue: AppTheme.device.rawValue])
            return AppTheme(rawValue: integer(forKey: SavedKeys.appTheme.rawValue)) ?? .device
        }
        set {
            set(newValue.rawValue, forKey: SavedKeys.appTheme.rawValue)
        }
    }

    var recentAddress: [AddressModel]? {
        get {
            guard let data = UserDefaults.standard.data(forKey: SavedKeys.recentAddresses.rawValue) else {
                return nil
            }
            let decoder = JSONDecoder()
            let obj = try? decoder.decode([AddressModel].self, from: data)
            return obj
        } set {
            let encoder = JSONEncoder()
            let data = try? encoder.encode(newValue)
            UserDefaults.standard.set(data, forKey: SavedKeys.recentAddresses.rawValue)
        }
    }
}


//MARK:- User defaults utilities
extension UserDefaults {
    func clearUserCache() {
        UserDefaults.standard.user = nil
        UserDefaults.standard.token = nil
        UserDefaults.standard.selectedAddress = nil
    }
}
