//
//  DateTimeTextField.swift
//  Quran Academy
//
//  Created by Mohamed Matloub on 1/17/21.
//  Copyright © 2021 Black-squares. All rights reserved.
//

import UIKit
import SwiftDate

class DateTimeTextField: UITextField{
	var timePicker = UIDatePicker()
	var date: Date?
	var format: String?
	var minimumDate: Date?{
		didSet{
			timePicker.minimumDate = minimumDate ?? Date()
			guard let oldDate = date ,
				let min = minimumDate,
				oldDate.timeIntervalSince1970 < min.timeIntervalSince1970
				else { return }
			
			self.text = ""
			self.date = nil
			
		}
	}
	
	lazy var datePickerMode: UIDatePicker.Mode = .dateAndTime
	
	var valueChangedAction: ((Date)->())?
	
	override func awakeFromNib() {
		super.awakeFromNib()
		setup()
		setupPickers()
	}
	
	func setup(){
		self.addTarget(self, action: #selector(timeBeginEditing(_:)), for: .editingDidBegin)
		self.addTarget(self, action: #selector(timeEndEditing(_:)), for: .editingDidEnd)
	}
	
	func setupPickers() {
        timePicker.minuteInterval = 15
		timePicker.datePickerMode = datePickerMode
		if #available(iOS 13.4, *) {
			timePicker.preferredDatePickerStyle = .wheels
		} else {
			// Fallback on earlier versions
		}
		timePicker.minimumDate = minimumDate ?? Date()
		self.inputView = timePicker
		
	}
	
	@objc func timeEndEditing(_ sender: UITextField) {
        self.text = self.timePicker.date.toString(.custom(format ?? ""))
		self.date = self.timePicker.date
		valueChangedAction?(timePicker.date)
	}
	
	
	@objc  func timeBeginEditing(_ sender: UITextField) {
		sender.inputView = timePicker
        timePicker.addTarget(self, action: #selector(pickerTimeChanged), for: UIControl.Event.valueChanged)
	}
	
	@objc func pickerTimeChanged(sender: Any!) {
		self.timeEndEditing(self)
	}
}
