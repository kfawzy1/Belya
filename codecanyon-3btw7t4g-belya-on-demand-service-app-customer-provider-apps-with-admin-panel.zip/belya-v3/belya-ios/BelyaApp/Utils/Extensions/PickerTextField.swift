//
//  PickerTextField.swift
//  Quran Academy
//
//  Created by Mohamed Matloub on 1/17/21.
//  Copyright © 2021 Black-squares. All rights reserved.
//

import UIKit

class PickerTextField: UITextField {
	var titleForItem: ((Int)-> String)?
	var dataCount: (() -> Int)?
	var didSelectItemAction: ((Int) -> Void)?
	let picker = UIPickerView()

	func setup() {
		picker.dataSource = self
		picker.delegate = self
		self.inputView = picker
		self.delegate = self
	}
}

extension PickerTextField: UIPickerViewDelegate, UIPickerViewDataSource {
	func numberOfComponents(in pickerView: UIPickerView) -> Int {
		1
	}

	func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
		return dataCount?() ?? 0
	}

	func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {

		return titleForItem?(row) ?? ""
	}

	func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
		self.text = titleForItem?(row) ?? ""
		didSelectItemAction?(row)
	}

}


extension PickerTextField: UITextFieldDelegate {
	func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
		if textField.text?.isEmpty ?? false {
			self.text = titleForItem?(0) ?? ""
			didSelectItemAction?(0)
		}
		return true
	}
}
