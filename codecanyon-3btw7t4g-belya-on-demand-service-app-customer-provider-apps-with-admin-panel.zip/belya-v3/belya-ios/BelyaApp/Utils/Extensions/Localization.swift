//
//  StringExtension.swift
//  Quran Academy
//
//  Created by Ahmed Hamdy on 02/12/2020.
//  Copyright © 2020 Balck-squares. All rights reserved.
//

import Foundation
import UIKit

enum Languages: String {
    case ar = "ar"
    case en = "en"
}

final class LocalizationManager {
    private static var privateShared : LocalizationManager?
    let languageKey = "languageKey"
    
    class func shared() -> LocalizationManager {
        guard let uwShared = privateShared else {
            privateShared = LocalizationManager()
            return privateShared!
        }
        return uwShared
    }
    
    private init() {}
    
    func changeLangauge(to language: Languages) {
        UserDefaults.standard.set(language.rawValue, forKey: languageKey)

        let semanticAttribue: UISemanticContentAttribute
        if LocalizationManager.shared().currentLanguage() == .en {
            semanticAttribue = .forceLeftToRight
        } else {
            semanticAttribue = .forceRightToLeft
        }
        
        UIView.appearance().semanticContentAttribute = semanticAttribue
        UIPageControl.appearance().semanticContentAttribute = semanticAttribue
        UILabel.appearance().semanticContentAttribute = semanticAttribue
        UIButton.appearance().semanticContentAttribute = semanticAttribue
        UIImageView.appearance().semanticContentAttribute = semanticAttribue
        UITableView.appearance().semanticContentAttribute = semanticAttribue
        UICollectionView.appearance().semanticContentAttribute = semanticAttribue
        UINavigationBar.appearance().semanticContentAttribute = semanticAttribue
        UITabBar.appearance().semanticContentAttribute = semanticAttribue
        UISearchBar.appearance().semanticContentAttribute = semanticAttribue
        UINavigationBar.appearance().semanticContentAttribute = semanticAttribue

//        switch UserDefaults.standard.currentUser {
//        case .student:
//            UIApplication.shared.keyWindow?.rootViewController = StudentTabBarController.instantiate(fromAppStoryboard: .StudentHome)
//        default:
//            UIApplication.shared.keyWindow?.rootViewController = InstructorTabBarController.instantiate(fromAppStoryboard: .InstructorHome)
//        }
    }

    func currentLanguage() -> Languages {
        return Languages(rawValue: UserDefaults.standard.string(forKey: languageKey) ?? "en")!
    }
    
    class func destroy() {
        privateShared = nil
    }
}

extension String {
    var localized: String {
        return NSLocalizedString(self, tableName: "Localizable", bundle: Bundle.main,
                                 value: self, comment: "")
    }
}

public extension UITextView {

    override func awakeFromNib() {
        super.awakeFromNib()
        if let text = text {
            self.text = text.localized
        }
    }
}

public extension UITextField {

    override func awakeFromNib() {
        super.awakeFromNib()
        if let placeholder = placeholder {
            self.placeholder = placeholder.localized
        }
    }
}

public extension UILabel {

    override func awakeFromNib() {
        super.awakeFromNib()
        if let text = text {
            self.text = text.localized
        }
    }
}


public extension UITabBarItem {

    override func awakeFromNib() {
        super.awakeFromNib()
        if let title = title {
            self.title = title.localized
        }
    }
}

public extension UIButton {

    override func awakeFromNib() {
        super.awakeFromNib()
        for state in [UIControl.State.normal, UIControl.State.highlighted, UIControl.State.selected, UIControl.State.disabled] {
            if let title = title(for: state) {
                setTitle(title.localized, for: state)
            }
        }
    }
}


extension UIViewController {
    func loopThroughSubViewAndAlignTextfieldText(subviews: [UIView]) {
        if subviews.count > 0 {
            for subView in subviews {
                if subView is UITextField && subView.tag <= 0{
                    let textField = subView as! UITextField
                    textField.textAlignment = LocalizationManager.shared().currentLanguage() == .ar ? .right: .left
                } else if subView is UITextView && subView.tag <= 0{
                    let textView = subView as! UITextView
                    textView.textAlignment = LocalizationManager.shared().currentLanguage() == .ar ? .right: .left
                }
                loopThroughSubViewAndAlignTextfieldText(subviews: subView.subviews)
            }
        }
    }

    //Align Label Text
    func loopThroughSubViewAndAlignLabelText(subviews: [UIView]) {
        if subviews.count > 0 {
            for subView in subviews {
                if subView is UILabel && subView.tag <= 0 {
                    let label = subView as! UILabel
                    label.textAlignment = LocalizationManager.shared().currentLanguage() == .ar ? .right : .left
                }
                loopThroughSubViewAndAlignLabelText(subviews: subView.subviews)
            }
        }
    }
}

extension UITableViewCell {
    func loopThroughSubViewAndAlignTextfieldText(subviews: [UIView]) {
        if subviews.count > 0 {
            for subView in subviews {
                if subView is UITextField && subView.tag <= 0{
                    let textField = subView as! UITextField
                    textField.textAlignment = LocalizationManager.shared().currentLanguage() == .ar ? .right: .left
                } else if subView is UITextView && subView.tag <= 0{
                    let textView = subView as! UITextView
                    textView.textAlignment = LocalizationManager.shared().currentLanguage() == .ar ? .right: .left
                }
                loopThroughSubViewAndAlignTextfieldText(subviews: subView.subviews)
            }
        }
    }

    //Align Label Text
    func loopThroughSubViewAndAlignLabelText(subviews: [UIView]) {
        if subviews.count > 0 {
            for subView in subviews {
                if subView is UILabel && subView.tag <= 0 {
                    let label = subView as! UILabel
                    label.textAlignment = LocalizationManager.shared().currentLanguage() == .ar ? .right : .left
                }
                loopThroughSubViewAndAlignLabelText(subviews: subView.subviews)
            }
        }
    }
}
extension UICollectionViewFlowLayout {
    open override var flipsHorizontallyInOppositeLayoutDirection: Bool {
        true
    }
}
