//
//  UIView+Designable.swift
//  Quran Academy
//
//  Created by Mohamed Matloub on 12/5/20.
//  Copyright © 2020 Balck-squares. All rights reserved.
//

import UIKit

public protocol NibDesignableProtocol: NSObjectProtocol {
	/**
	Identifies the view that will be the superview of the contents loaded from
	the Nib. Referenced in setupNib().

	- returns: Superview for Nib contents.
	*/
	var nibContainerView: UIView { get }
	// MARK: - Nib loading

	/**
	Called to load the nib in setupNib().

	- returns: UIView instance loaded from a nib file.
	*/
	func loadNib() -> UIView
	/**
	Called in the default implementation of loadNib(). Default is class name.

	- returns: Name of a single view nib file.
	*/
	func nibName() -> String
}

extension NibDesignableProtocol {
	// MARK: - Nib loading

	/**
	Called to load the nib in setupNib().

	- returns: UIView instance loaded from a nib file.
	*/
	public func loadNib() -> UIView {
		let bundle = Bundle(for: type(of: self))
		let nib = UINib(nibName: self.nibName(), bundle: bundle)

        guard let view = nib.instantiate(withOwner: self, options: nil).first as? UIView else {
			return UIView()
		}
		return view
	}

	// MARK: - Nib loading

	/**
	Called in init(frame:) and init(aDecoder:) to load the nib and add it as a subview.
	*/
	func setupNib() {
		let view = self.loadNib()
		self.nibContainerView.addSubview(view)
		view.translatesAutoresizingMaskIntoConstraints = false
		let bindings = ["view": view]
		self.nibContainerView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[view]|", options: [], metrics: nil, views: bindings))
		self.nibContainerView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[view]|", options: [], metrics: nil, views: bindings))
	}
}

extension UIView {
	public var nibContainerView: UIView {
		return self
	}
	/**
	Called in the default implementation of loadNib(). Default is class name.

	- returns: Name of a single view nib file.
	*/
	@objc open func nibName() -> String {
		return type(of: self).description().components(separatedBy: ".").last!
	}

	public func addSubviewAndPinToEdges(_ view: UIView, constants: UIEdgeInsets = .zero, respectsLanguage: Bool = true) {
		view.translatesAutoresizingMaskIntoConstraints = false
		addSubview(view)
		pinToEdges(view: view, constants: constants, respectsLanguage: respectsLanguage)
	}

	public func pinToEdges(view: UIView, constants: UIEdgeInsets = .zero, respectsLanguage: Bool = true) {
		let constraints: [NSLayoutConstraint]
		constraints = [
			view.trailingAnchor.constraint(equalTo: trailingAnchor, constant: constants.right),
			view.bottomAnchor.constraint(equalTo: bottomAnchor, constant: constants.bottom),
			view.leadingAnchor.constraint(equalTo: leadingAnchor, constant: constants.left),
			view.topAnchor.constraint(equalTo: topAnchor, constant: constants.top)
		]
		NSLayoutConstraint.activate(constraints)
	}
}

open class NibDesignable: UIView, NibDesignableProtocol {
    // MARK: - Initializer
    override public init(frame: CGRect) {
        super.init(frame: frame)
        self.setupNib()
    }
    
    // MARK: - NSCoding
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setupNib()
    }
}
extension UIView {
	open class var nibName: String {
		return String(describing: self)
	}

	@discardableResult
	public func loadNib() -> UIView? {
		let nibName = type(of: self).nibName
		return Bundle.main.loadNibNamed(nibName, owner: self, options: nil)?.first as? UIView
	}

	public func loadViewFromNib(nibName: String) -> UIView? {
		let bundle = Bundle(for: type(of: self))
		let nib = UINib(nibName: nibName, bundle: bundle)
		return nib.instantiate(
			withOwner: self,
			options: nil).first as? UIView
	}
}
