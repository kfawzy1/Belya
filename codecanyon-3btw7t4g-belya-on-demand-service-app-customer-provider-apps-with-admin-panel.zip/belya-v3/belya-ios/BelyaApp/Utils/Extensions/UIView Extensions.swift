//
//  UIView Etensions.swift
//  Quran Academy
//
//  Created by Mohamed Matloub on 12/5/20.
//  Copyright © 2020 Balck-squares. All rights reserved.
//

import UIKit

extension UIView {
	@IBInspectable var borderWidth: CGFloat {
		set {
			layer.borderWidth = newValue
		}
		get {
			return layer.borderWidth
		}
	}

	@IBInspectable var cornerRadius: CGFloat {
		set {
			layer.cornerRadius = newValue
		}
		get {
			return layer.cornerRadius
		}
	}

	@IBInspectable var borderColor: UIColor? {
		set {
			guard let uiColor = newValue else { return }
			layer.borderColor = uiColor.cgColor
		}
		get {
			guard let color = layer.borderColor else { return nil }
			return UIColor(cgColor: color)
		}
	}

	@IBInspectable dynamic var  hasRoundCorner: Bool {
		get {
			return self.layer.cornerRadius == self.bounds.size.height / 2
		}
		set {
			self.roundCorner()
		}
	}
	func roundCorner() {
		let corner = self.bounds.size.height / 2
		self.layer.cornerRadius = corner
		self.clipsToBounds = true
	}
}
