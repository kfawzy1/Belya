//
//  DynamicHeightTableView.swift
//  Swvl
//
//  Created by Mohamed Hamed on 7/13/18.
//  Copyright © 2018 Swvl Inc. All rights reserved.
//

import UIKit

class DynamicHeightTableView: UITableView {
    override var contentSize: CGSize {
        didSet {
            self.invalidateIntrinsicContentSize()
        }
    }

    override var intrinsicContentSize: CGSize {
        self.layoutIfNeeded()
        return contentSize
    }
}
