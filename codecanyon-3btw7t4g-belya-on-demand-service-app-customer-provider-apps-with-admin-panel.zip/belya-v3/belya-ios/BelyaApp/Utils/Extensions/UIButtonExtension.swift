//
//  UIButtonExtension.swift
//  Quran Academy
//
//  Created by Ahmed Hamdy on 21/01/2021.
//  Copyright © 2021 Black-squares. All rights reserved.
//

import UIKit.UIButton

extension UIButton {
    func disable(alpha: CGFloat = 0.5) {
        self.isEnabled = false
        self.alpha = alpha
    }

    func enable() {
        isEnabled = true
        alpha = 1
    }
}
