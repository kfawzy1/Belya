//
//  AppDelegate+Firebase.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 24/11/2021.
//

import Foundation
import Firebase
import UserNotifications
import FirebaseMessaging
import Moya

extension AppDelegate: UNUserNotificationCenterDelegate, MessagingDelegate {
    func configureFirebase(application: UIApplication) {
        FirebaseApp.configure()
        let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
        UNUserNotificationCenter.current().requestAuthorization(
            options: authOptions,
            completionHandler: {_, _ in })
        UNUserNotificationCenter.current().delegate = self
        application.registerForRemoteNotifications()
        Messaging.messaging().delegate = self
    }

    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        print("Firebase registration token: \(fcmToken ?? "")")
        if let token = fcmToken {
            registerFcmToken(token)
        }
    }
    
    func registerFcmToken(_ token: String) {
        var task: Task
        task = .requestParameters(parameters: ["fcm_token": token], encoding: JsonEncoding.default)

        let target = BelyaTarget(path: "users/register-fcm-token", method: .patch, task: task)

        let provider = MoyaProvider<BelyaTarget>()
        provider.request(target) { result in
            switch result {
            case .success(let res):
                print(res)
            case .failure(let error):
                debugPrint(error)
            }
        }
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        _ = notification.request.content.userInfo
        NotificationCenter.default.post(name: Notification.Name("didReceiveNotification"), object: nil)
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        deepLink(payload: userInfo)
        completionHandler()
    }

    fileprivate func deepLink(payload: [AnyHashable : Any]) {
        if let noteType = (payload["aps"] as? [String: Any])?["category"] as? String { }
    }
}

enum NotificationType: String {
    case InstructorSessionQuestionsAction = "Instructor::SessionQuestionsAction"
    case InstructorNotificationsAction = "Instructor::NotificationsAction"
    case InstructorSessionsAction = "Instructor::SessionsAction"
    case InstructorHomeAction = "Instructor::HomeAction"
    case StudentSessionsAction = "Student::SessionsAction"
    case StudentNotificationsAction = "Student::NotificationsAction"
}

// MARK: - GenericResponse
struct GenericResponse: Codable {
    let message: String
}
