//
//  SplashViewController.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 07/09/2021.
//

import UIKit

class SplashViewController: UIViewController {
    @IBOutlet weak var indicatorView: BaseActivityIndicator!
    @IBOutlet weak var getStartedButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    @Api(method: .get, path: .configs)
    var configs: Configs?
    
    let defaults = UserDefaults.standard
    var cancellable: Cancellable?
    
    fileprivate func getConfigs() {
        indicatorView.startAnimating()
        _configs.callApi()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        handleConfigsResponse()
        if defaults.value(forKey: SavedKeys.firstTimeCallGetConfigs.rawValue) == nil {
            getConfigs()
        } else if let date = defaults.value(forKey: SavedKeys.firstTimeCallGetConfigs.rawValue) as? Date {
            let calculatingTime = Calendar.current
            let components = calculatingTime.dateComponents([.hour], from: date, to: Date())
            let differenceBetweenTwoTime = components.hour
            if let differenceHour = differenceBetweenTwoTime, differenceHour > 23 {
                getConfigs()
            } else {
                DispatchQueue.main.async {
                    self.indicatorView.isHidden = true
                    self.getStartedTapped(UIButton())
                }
            }
        }
    }
    
    private func setupUI() {
        if UserDefaults.standard.appTarget == .Belya {
            view.backgroundColor = UIColor(named: "accent")
            titleLabel.textColor = UIColor(named: "contentOnColor")
            descriptionLabel.textColor = UIColor(named: "contentOnColor")
            indicatorView.setIndicatorColor(UIColor(named: "backgroundTertiary") ?? .blue)
        } else {
            view.backgroundColor = UIColor(named: "backgroundPrimary")
            titleLabel.textColor = UIColor(named: "contentPrimary")
            descriptionLabel.textColor = UIColor(named: "contentPrimary")
            indicatorView.setIndicatorColor(UIColor(named: "accent") ?? .blue)
        }
    }

    fileprivate func handleConfigsResponse() {
        self.cancellable = _configs.$result.sink { [weak self] res in
            self?.indicatorView.stopAnimating()
            switch res {
            case .success(value: let configs):
                UserDefaults.standard.configs = configs
                UserDefaults.standard.setValue(Date(), forKey: SavedKeys.firstTimeCallGetConfigs.rawValue)
                UIView.transition(with: self?.getStartedButton ?? UIView(), duration: 0.5, options: .transitionCrossDissolve, animations: {
                    self?.indicatorView.isHidden = true
                    self?.getStartedButton.isHidden = false
                }, completion: nil)
                
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }
    }
    
    @IBAction func getStartedTapped(_ sender: UIButton) {
        if UserDefaults.standard.user != nil {
            navigateToHome()
        } else {
            let loginController = LoginViewController()
            loginController.modalPresentationStyle = .fullScreen
            present(loginController, animated: true, completion: nil)
        }
    }
    
    fileprivate func presentProviderTabBar() {
        let mainTabBar = ProviderHomeTabBarController.instantiate(fromAppStoryboard: .ProviderHome)
        mainTabBar.modalPresentationStyle = .fullScreen
        present(mainTabBar, animated: true, completion: nil)
    }
    
    fileprivate func presentCustomerTabBar() {
        let mainTabBar = CustomerHomeTabBarViewController.instantiate(fromAppStoryboard: .CustomerHome)
        mainTabBar.modalPresentationStyle = .fullScreen
        present(mainTabBar, animated: true, completion: nil)
    }
    
    fileprivate func navigateToHome() {
        switch UserDefaults.standard.appTarget {
        case .Belya: presentCustomerTabBar()
        case .BelyaProvider: presentProviderTabBar()
        }
    }
}
