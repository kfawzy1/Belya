//
//  Configs.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 09/09/2021.
//

import Foundation

// MARK: - Configs
struct Configs: Codable {
    let categories: [Category]
    let services: [Service]
    let statuses: [Status]
    let paymentSettings: PaymentSettings
    let paymentMethods: [PaymentMethod]
}

// MARK: - Category
struct Category: Codable {
    let key: CategoryKey
    let icon, name, color: String
}

enum CategoryKey: String, Codable {
    case cleaners
    case electricians
    case mechanics
    case chefs
    case painters
    case plumbers
    case photographers
    case carpenters
}

// MARK: - PaymentMethod
struct PaymentMethod: Codable {
    let key, name: String
    let enabled: Bool
}

// MARK: - PaymentSettings
struct PaymentSettings: Codable {
    let taxEnabled: Bool
    let taxPercentage: String
    let currency: Currency

    enum CodingKeys: String, CodingKey {
        case taxEnabled = "tax_enabled"
        case taxPercentage = "tax_percentage"
        case currency
    }
}

// MARK: - Currency
struct Currency: Codable {
    let name, code, symbol: String
}

// MARK: - Service
struct Service: Codable {
    let key, name, serviceDescription, color: String
    let icon: String
    let duration: Int
    let price, rating: String
    let reviewsCount, bookingsCount: Int
    let categoryKey: String

    enum CodingKeys: String, CodingKey {
        case key, name
        case serviceDescription = "description"
        case color, icon, duration, price, rating, reviewsCount, bookingsCount, categoryKey
    }
}

// MARK: - Status
struct Status: Codable {
    let key, name: String
}
