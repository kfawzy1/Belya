//
//  SettingsViewController.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 28/10/2021.
//

import UIKit

class SettingsViewController: UIViewController {

    @IBOutlet weak var themeSettingsView: SettingsCardView!
    @IBOutlet weak var languageSettingsView: SettingsCardView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "settings".localized
        themeSettingsView.setupView(settingsOption: .theme)
        languageSettingsView.setupView(settingsOption: .language)

        var tapGesture = UITapGestureRecognizer(target: self, action: #selector(themeTapped))
        themeSettingsView.addGestureRecognizer(tapGesture)

        tapGesture = UITapGestureRecognizer(target: self, action: #selector(languageTapped))
        languageSettingsView.addGestureRecognizer(tapGesture)

    }

    @objc func themeTapped() {
        let themeVC = ChooseThemeViewController()
        themeVC.delegate = self
        themeVC.modalPresentationStyle = .overCurrentContext
        present(themeVC, animated: true, completion: nil)
    }

    @objc func languageTapped() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
}

//MARK:- ChooseThemeDelegate
extension SettingsViewController: ChooseThemeDelegate {
    func themeSelected() {
        //refresh the view
        themeSettingsView.setupView(settingsOption: .theme)
    }
}
