//
//  AppLanguages.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 30/10/2021.
//

import Foundation

enum AppLanguagesConstants: String, CaseIterable {
    case arabic = "ar"
    case english = "en"
}

class AppLanguages {
    static func getCurrentLanguageText() -> String {
        let currentLocale = Locale.preferredLanguages[0]
        if currentLocale.starts(with: AppLanguagesConstants.english.rawValue) {
            return "language_english".localized
        } else if currentLocale.starts(with: AppLanguagesConstants.arabic.rawValue) {
            return "language_arabic".localized
        } else {
            return currentLocale
        }
    }
}
