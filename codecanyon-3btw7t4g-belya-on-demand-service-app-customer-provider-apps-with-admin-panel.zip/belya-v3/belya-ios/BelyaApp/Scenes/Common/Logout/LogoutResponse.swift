//
//  LogoutResponse.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 30/10/2021.
//

import Foundation

struct LogoutResponse: Codable {
    let message: String
}
