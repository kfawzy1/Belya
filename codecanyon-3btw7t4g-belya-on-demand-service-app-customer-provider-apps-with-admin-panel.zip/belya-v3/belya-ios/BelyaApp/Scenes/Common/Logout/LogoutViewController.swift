//
//  LogoutViewController.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 30/10/2021.
//

import UIKit

class LogoutViewController: UIViewController {

    @Api(method: .post, path: .logout)
    var logoutResponse: LogoutResponse?
    var cancellable: Cancellable?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        handleLogoutResponse()
    }

    private func handleLogoutResponse() {
        cancellable = _logoutResponse.$result.sink(receiveValue: { [weak self] resultResponse in
            self?.stopActivityIndicator()
            switch resultResponse {
            case .success(_):
                UserDefaults.standard.clearUserCache()
                let splashScreen = SplashViewController.instantiate(fromAppStoryboard: .Main)
                UIApplication.shared.keyWindow?.rootViewController = splashScreen
            default:
                break
            }
        })
    }

    @IBAction func logout(_ sender: UIButton) {
        self.showActivityIndicator()
        _logoutResponse.callApi()
    }

    @IBAction func cancelAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
