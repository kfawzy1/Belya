//
//  AboutViewController.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 24/10/2021.
//

import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "about".localized
    }

}
