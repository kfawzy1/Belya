//
//  UpdateProfileRequestParameters.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 28/10/2021.
//

import Foundation

struct UpdateProfileRequestParameters: Codable {
    var firstName: String
    var lastName: String
    var email: String

    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case lastName = "last_name"
        case email
    }
}
