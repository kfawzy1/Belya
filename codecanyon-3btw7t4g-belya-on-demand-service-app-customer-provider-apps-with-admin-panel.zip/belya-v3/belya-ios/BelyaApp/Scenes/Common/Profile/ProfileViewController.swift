//
//  ProfileViewController.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 28/10/2021.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var firstNameField: CustomTextField!
    @IBOutlet weak var lastNameField: CustomTextField!
    @IBOutlet weak var emailField: CustomTextField!

    @Api(method: .patch, path: .updateProfile, encoding: JsonEncoding.default)
    var updateProfileResponse: User?
    var cancellable: Cancellable?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        localize()
        updateFromUserDefaults()
        cancellable = _updateProfileResponse.$result.sink { [weak self] result in
            self?.stopActivityIndicator()
            switch result {
            case .error: break
            case .success(let updatedUser):
                UserDefaults.standard.user = updatedUser
                SwiftMessageHelper.showMessage(message: "profile_updated_successfully".localized)
            default:
                break
            }
        }
    }

    func localize() {
        title = "profile".localized
        firstNameField.placeholder = "first_name".localized
        lastNameField.placeholder = "last_name".localized
        emailField.placeholder = "email".localized
    }

    func updateFromUserDefaults() {
        if let user = UserDefaults.standard.user {
            firstNameField.text = user.firstName
            lastNameField.text = user.lastName
            emailField.text = user.email
        }
    }

    @IBAction func save(_ sender: UIButton) {
        guard let firstName = firstNameField.text,
              firstName.isValidString,
              let lastName = lastNameField.text,
              lastName.isValidString else {
                  SwiftMessageHelper.showMessage(theme: .error, message: "complete_profile".localized)
                  return
              }
        guard let email = emailField.text,
              email.isValidEmail else {
                  SwiftMessageHelper.showMessage(theme: .error, message: "invalid_email".localized)
                  return
              }
        let profile = UpdateProfileRequestParameters(firstName: firstName, lastName: lastName, email: email)

        showActivityIndicator()
        _updateProfileResponse.callApi(parameters: profile)
    }
}
