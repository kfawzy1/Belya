//
//  ContactSupportViewController.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 28/10/2021.
//

import UIKit

class ContactSupportViewController: UIViewController {

    let phone = "+1222333444"
    let email = "support@belya.com"

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func close(_ sender: UITapGestureRecognizer) {
        dismiss(animated: true)
    }

    @IBAction func openPhone(_ sender: UITapGestureRecognizer) {
        if let url = URL(string: "tel://\(phone)") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }

    @IBAction func openEmail(_ sender: UITapGestureRecognizer) {
        if let url = URL(string: "mailto:\(email)") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
}
