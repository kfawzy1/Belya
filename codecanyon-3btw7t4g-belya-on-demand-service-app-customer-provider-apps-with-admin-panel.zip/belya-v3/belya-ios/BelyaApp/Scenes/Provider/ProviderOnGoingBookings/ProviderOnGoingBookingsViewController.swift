//
//  ProviderOnGoingBookingsViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 17/10/2021.
//

import UIKit
import SwiftUI

class ProviderOnGoingBookingsViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var noBookingView: UIStackView!
    @IBOutlet weak var collectionView: UICollectionView!{
        didSet{
            collectionView.register(UINib(nibName: "ProviderOnGoingBookingsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ProviderOnGoingBookingsCollectionViewCell")
        }
    }
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!

    @Api(method: .get, path: .bookings, encoding: URLEncoding.default)
   // var bookings: [Booking]?
    var bookingsResponse: BookingResponse?
    var cancellable: Cancellable?
    let cellHeight: CGFloat = 112
    let emtpyViewHeight: CGFloat = 400
    let cellMargin: CGFloat = 16

    override func viewDidLoad() {
        super.viewDidLoad()
        handleBookingsResponse()
        RefreshUtils.addPullToRefresh(controller: self, scrollView: scrollView, refreshAction: #selector(refresh))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? ProviderHomeTabBarController {
            tabBarVC.showTabBar()
        }
        fetchData()
    }
    
    @objc func refresh() {
        scrollView.refreshControl?.endRefreshing()
        fetchData()
    }
    
    fileprivate func fetchData() {
        showActivityIndicator()
        _bookingsResponse.callApi(parameters: StatusRequestParameters(status: "accepted,on_the_way,arrived,in_progress,pending_approval,pending_payment"))

    }
    fileprivate func handleBookingsResponse() {
        self.cancellable = _bookingsResponse.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            switch res {
            case .success(value: let bookingsResponse):
                if bookingsResponse.data.isEmpty {
                //    self?.collectionView.isHidden = true
                    self?.noBookingView.isHidden = false
                } else {
                    self?.collectionView.reloadData()
                }
                self?.updateViewHeight()
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }
    }
}
extension ProviderOnGoingBookingsViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bookingsResponse?.data.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "ProviderOnGoingBookingsCollectionViewCell", for: indexPath) as? ProviderOnGoingBookingsCollectionViewCell else {
                return UICollectionViewCell()
            }
        cell.booking = bookingsResponse?.data[indexPath.row]
        return cell
   }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = ProviderBookingsDetailsViewController()
        vc.booking = bookingsResponse?.data[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
   
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.invalidateLayout()
        return CGSize(width: collectionView.frame.width - 24, height: cellHeight)
    }
    
}

//MARK:- handle view height
extension ProviderOnGoingBookingsViewController {
    func updateViewHeight() {
        guard let list = bookingsResponse?.data else { return }
        if list.count == 0 {
            collectionViewHeight.constant = emtpyViewHeight
        } else {
            collectionViewHeight.constant = CGFloat(list.count) * (cellHeight + cellMargin)
        }
    }
}

enum BookingStatus: String {
    case new
    case accepted
    case onTheWay = "on_the_way"
    case arrived
    case inProgress = "in_progress"
    case pendingApproval = "pending_approval"
    case pendingPayment = "pending_payment"
    case done
    case reviewed
    case canceled
    
    var backgroundColor: UIColor {
        switch self {
        case .new:
            return UIColor(named: "yellow400") ?? .yellow
        case .accepted:
            return UIColor(named: "orange400") ?? .orange
        case .onTheWay:
            return UIColor(named: "brown400") ?? .brown
        case .arrived:
            return UIColor(named: "blue400") ?? .blue
        case .inProgress:
            return UIColor(named: "purple400") ?? .blue
        case .pendingApproval:
            return UIColor(named: "cobalt400") ?? .yellow
        case .pendingPayment:
            return UIColor(named: "platinum400") ?? .yellow
        case .done:
            return UIColor(named: "green400") ?? .green
        case .reviewed:
            return UIColor(named: "green400") ?? .green
        case .canceled:
            return UIColor(named: "red400") ?? .red
        }
    }
}

