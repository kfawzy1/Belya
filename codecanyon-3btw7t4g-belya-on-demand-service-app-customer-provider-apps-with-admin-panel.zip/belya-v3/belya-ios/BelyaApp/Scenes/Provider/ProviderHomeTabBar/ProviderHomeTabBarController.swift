//
//  ProviderHomeTabBarController.swift
//  Belya-Provider
//
//  Created by Hussein Kishk on 11/09/2021.
//

import UIKit

class ProviderHomeTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
      //  UserDefaults.standard.configs?.categories.first?.name
        // Do any additional setup after loading the view.
    }
    
    func hideTabbar() {
        tabBar.isHidden = true
    }

    func showTabBar() {
        tabBar.isHidden = false
    }
}
