//
//  ProviderNewBookingsViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 17/10/2021.
//

import UIKit

class ProviderNewBookingsViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var noBookingView: UIStackView!
    @IBOutlet weak var collectionView: UICollectionView!{
        didSet {
            collectionView.register(UINib(nibName: "ProviderNewBookingsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ProviderNewBookingsCollectionViewCell")
        }
    }
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!

    @Api(method: .get, path: .bookingLeads)
    var bookingsResponse: BookingResponse?
    var cancellable: Cancellable?
    let cellHeight: CGFloat = 112
    let emtpyViewHeight: CGFloat = 400
    let cellMargin: CGFloat = 16

    override func viewDidLoad() {
        super.viewDidLoad()
        handleBookingsResponse()
        RefreshUtils.addPullToRefresh(controller: self, scrollView: scrollView, refreshAction: #selector(refresh))
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? ProviderHomeTabBarController {
            tabBarVC.showTabBar()
        }
        fetchData()
    }

    @objc func refresh(_ sender: AnyObject) {
        scrollView.refreshControl?.endRefreshing()
        fetchData()
    }
    
    fileprivate func fetchData() {
        showActivityIndicator()
        _bookingsResponse.callApi()
    }
    
    fileprivate func handleBookingsResponse() {
        self.cancellable = _bookingsResponse.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            switch res {
            case .success(value: let bookingsResponse):
                if bookingsResponse.data.isEmpty {
                  //  self?.collectionView.isHidden = true
                    self?.noBookingView.isHidden = false
                } else {
                    self?.collectionView.reloadData()
                }
                self?.updateViewHeight()
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }
    }
}

extension ProviderNewBookingsViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bookingsResponse?.data.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "ProviderNewBookingsCollectionViewCell", for: indexPath) as? ProviderNewBookingsCollectionViewCell else {
                return UICollectionViewCell()
            }
        cell.booking = bookingsResponse?.data[indexPath.row]

        return cell
   }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = ProviderBookingsDetailsViewController()
        vc.booking = bookingsResponse?.data[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
   
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.invalidateLayout()
        return CGSize(width: collectionView.frame.width - 24, height: cellHeight)
    }
}

//MARK:- handle view height
extension ProviderNewBookingsViewController {
    func updateViewHeight() {
        guard let list = bookingsResponse?.data else { return }
        if list.count == 0 {
            collectionViewHeight.constant = emtpyViewHeight
        } else {
            collectionViewHeight.constant = CGFloat(list.count) * (cellHeight + cellMargin)
        }
    }
}
