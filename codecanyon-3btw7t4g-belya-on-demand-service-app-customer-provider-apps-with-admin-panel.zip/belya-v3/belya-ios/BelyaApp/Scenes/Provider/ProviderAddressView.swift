//
//  ProviderAddressView.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 25/10/2021.
//

import UIKit
import MapKit
import GoogleMaps

class ProviderAddressView: NibDesignable {

    @IBOutlet weak var addressLabel: UILabel!
    var booking: Booking?
    var showDirection: (() -> Void)?
       
    override func awakeFromNib() {
        super.awakeFromNib()
        setup()
    }

    func setup() {
        layer.cornerRadius = 8
        borderWidth = 1
        borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.08)
    }
   

    @IBAction func showAddressButtonIsTapped(_ sender: Any) {
        showDirection?()
    }
}
