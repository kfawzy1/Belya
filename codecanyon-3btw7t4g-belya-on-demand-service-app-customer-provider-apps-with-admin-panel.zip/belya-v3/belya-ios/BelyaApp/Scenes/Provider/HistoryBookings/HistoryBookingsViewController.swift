//
//  HistoryBookingsViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 20/10/2021.
//

import UIKit

struct StatusRequestParameters: Codable { var status: String }
class HistoryBookingsViewController: UIViewController {
    
    @IBOutlet weak var noBookingView: UIStackView!
    @IBOutlet weak var collectionView: UICollectionView! {
        didSet{
            collectionView.register(UINib(nibName: "HistoryBookingsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HistoryBookingsCollectionViewCell")
        }
    }

    @Api(method: .get, path: .bookings, encoding: URLEncoding.default)
    var bookingsResponse: BookingResponse?
    let refreshControl = UIRefreshControl()
    var cancellable: Cancellable?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "history_bookings".localized
        handleBookingsResponse()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        collectionView.addSubview(refreshControl)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchData()
    }

    @objc func refresh(_ sender: AnyObject) {
        fetchData()
    }

    fileprivate func fetchData() {
        showActivityIndicator()
        _bookingsResponse.callApi(parameters: StatusRequestParameters(status: "canceled,done,reviewed"))
    }

    fileprivate func handleBookingsResponse() {
        self.cancellable = _bookingsResponse.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            self?.refreshControl.endRefreshing()
            switch res {
            case .success(value: let bookingsResponse):
                if bookingsResponse.data.isEmpty {
                    self?.noBookingView.isHidden = false
                } else {
                    self?.noBookingView.isHidden = true
                    self?.collectionView.reloadData()
                }
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }
    }
}

extension HistoryBookingsViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bookingsResponse?.data.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "HistoryBookingsCollectionViewCell", for: indexPath) as? HistoryBookingsCollectionViewCell else {
                return UICollectionViewCell()
            }
        cell.booking = bookingsResponse?.data[indexPath.row]
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.invalidateLayout()
        return CGSize(width: collectionView.frame.width - 24, height: 112)
    }    
}
