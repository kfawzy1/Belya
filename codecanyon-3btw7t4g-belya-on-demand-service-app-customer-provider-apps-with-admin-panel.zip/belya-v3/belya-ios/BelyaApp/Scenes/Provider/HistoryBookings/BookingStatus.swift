//
//  BookingStatus.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 20/10/2021.
//

import Foundation
import UIKit
enum BookingsStatus: String {
    case new
    case accepted
    case onTheWay = "on_the_way"
    case done
    case reviewed
    case canceled

    var backgroundColor: UIColor {
        switch self {
        case .new:
            return UIColor(named: "yellow400") ?? .yellow
        case .accepted:
            return UIColor(named: "orange400") ?? .orange
        case .onTheWay:
            return UIColor(named: "brown400") ?? .brown
        case .done:
            return UIColor(named: "green400") ?? .green
        case .reviewed:
            return UIColor(named: "green400") ?? .green
        case .canceled:
            return UIColor(named: "red400") ?? .red
        }
    }
}
