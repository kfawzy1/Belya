//
//  ProviderMenuViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 16/10/2021.
//

import UIKit

class ProviderMenuViewController: UIViewController {
    @IBOutlet weak var providerMenuCollectionView: UICollectionView!{
        didSet {
            providerMenuCollectionView.register(UINib(nibName: "ProviderMenuCollectionViewCell", bundle: .main), forCellWithReuseIdentifier: "ProviderMenuCollectionViewCell")
        }
    }

    var menuItem: [ProviderMenuItems]?

    override func viewDidLoad() {
        menuItem = [.profile ,.settings ,.categories ,.historyBookings,.support,.logout]
        navigationController?.setNavigationBarHidden(false, animated: true)
        navigationController?.navigationItem.hidesBackButton = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? ProviderHomeTabBarController {
            tabBarVC.showTabBar()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        providerMenuCollectionView.reloadData()
    }
}

extension ProviderMenuViewController:UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return menuItem?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = providerMenuCollectionView.dequeueReusableCell(
            withReuseIdentifier: "ProviderMenuCollectionViewCell", for: indexPath) as? ProviderMenuCollectionViewCell else {
                return UICollectionViewCell()
            }
        cell.menuLabel.text = menuItem?[indexPath.row].title.localized
        cell.menuImage.image = menuItem?[indexPath.row].image
        return cell
    }
     
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let menuItemSelected = menuItem?[indexPath.row]
        let selectedController = menuItemSelected?.navigationTarget
        let tabBarVC = tabBarController as? ProviderHomeTabBarController

        if let controller = selectedController {
            switch menuItemSelected {
            case .profile, .settings,.categories, .historyBookings:
                navigationController?.pushViewController(controller, animated: true)
                tabBarVC?.hideTabbar()
            case .support:
                controller.modalPresentationStyle = .overCurrentContext
                self.tabBarController?.present(controller, animated: true, completion: nil)
            case .none:
                break
            case .some(.logout):
                controller.modalPresentationStyle = .overCurrentContext
                self.tabBarController?.present(controller, animated: true, completion: nil)
            }
        }
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.invalidateLayout()
        return CGSize(width: (collectionView.frame.width / 2) - 32, height: 78)

    }
}
