//
//  ProviderMenu.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 20/10/2021.
//

import Foundation
import UIKit

enum ProviderMenuItems {
    case profile
    case settings
    case categories
    case historyBookings
    case support
    case logout
    
    var title : String {
        switch self {
        case .profile:
            return "profile"
        case .settings:
            return "settings"
        case .categories:
            //not in localizableFile
            return "categories"
        case .historyBookings:
            return "history_bookings"
        case .support:
            return "support"
        case .logout:
            return "logout"
        }
    }

    var image : UIImage {
        switch self{
        case .profile:
            return UIImage(named: "profile") ?? UIImage()
        case .settings:
            return UIImage(named: "setting") ?? UIImage()
        case .categories:
            return UIImage(named: "categories") ?? UIImage()
        case .historyBookings:
            return UIImage(named: "historyBooking") ?? UIImage()
        case .support:
            return UIImage(named: "support") ?? UIImage()
        case .logout:
            return  UIImage(named: "logout") ?? UIImage()
        }
    }

    var navigationTarget: UIViewController? {
        switch self {
        case .profile:
            return ProfileViewController()
        case .settings:
            return SettingsViewController()
        case .categories:
            return ProviderChooseCategoriesViewController()
        case .historyBookings:
            return HistoryBookingsViewController()
        case .support:
            return ContactSupportViewController()
        case .logout:
            return LogoutViewController()
        }
    }
}
