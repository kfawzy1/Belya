//
//  ProviderBookingsDetailsViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 25/10/2021.
//

import UIKit
import CloudKit

class ProviderBookingsDetailsViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var servicePriceView: ServicePriceView!
    @IBOutlet weak var serviceStatusView: ServiceStatusView!
    @IBOutlet weak var callCustomer: CallProviderView!
    @IBOutlet weak var addressView: ProviderAddressView!
    @IBOutlet weak var bookingTimeView: CustomerConfirmingBookingTimeView!
    @IBOutlet weak var notesView: CustomerConfirmingNotesView!
    @IBOutlet weak var paymentSummaryView: CustomerConfirmingPaymentSummary!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var waitingCustomerApprovalLabel: UILabel!
    
    @Api(method: .get, path: .bookings)
    var booking: Booking?
  
    let refreshControl = UIRefreshControl()
    var cancellable : Cancellable?


    override func viewDidLoad() {
        super.viewDidLoad()
        title = "booking_details".localized
        handleBookingResponse()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        scrollView.refreshControl = refreshControl
    }
    @objc func refresh(_ sender: AnyObject) {
       fetchData()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? ProviderHomeTabBarController {
            tabBarVC.hideTabbar()
        }
        NotificationCenter.default.addObserver(self, selector: #selector(onDidReceiveNotification), name: Notification.Name("didReceiveNotification"), object: nil)
        loadUI()
        fetchData()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(
            self,
            name: NSNotification.Name(rawValue: "didReceiveNotification"),
            object: nil)
    }

    @objc func onDidReceiveNotification() {
        fetchData()
    }

    fileprivate func fetchData() {
        guard let booking = booking else { return }
        showActivityIndicator()
        _booking.method = .get
        _booking.callApi(urlParameter: "/\(booking.key)")

    }
    fileprivate func postData(action: String) {
        guard let booking = booking else { return }
        showActivityIndicator()
        _booking.method = .post
        _booking.callApi(urlParameter: "/\(booking.key)/\(action)")

    }

    fileprivate func handleBookingResponse() {
        self.cancellable = _booking.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            self?.refreshControl.endRefreshing()
            switch res {
            case .success:
                self?.loadUI()
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }
    }

    fileprivate func loadUI() {
        servicePriceView.booking = booking
        serviceStatusView.serviceNameLabel?.text = booking?.service.name
        serviceStatusView.statusLabelView?.backgroundColor = BookingStatus(rawValue: booking?.status.key ?? "")?.backgroundColor
        serviceStatusView.statusLabel?.text = booking?.status.name
        serviceStatusView.addressLabel?.text = "\(booking?.addressName ?? "") \(booking?.addressDetails ?? "")"
        callCustomer.titleLabel.text = "call_customer".localized
        callCustomer.providerNameLabel.text = "\(booking?.provider?.firstName ?? "") \(booking?.provider?.lastName ?? "")"
        callCustomer.providerNumberLabel.text = booking?.customer?.phoneNumber
        callCustomer.callAction = {
            guard let number = self.booking?.customer?.phoneNumber else { return }
            if let url = URL(string: "tel://\(number)") {
                UIApplication.shared.openURL(url)
            }
        }
        addressView.addressLabel.text = "\(String(describing: booking?.addressName ?? "")) \n\(booking?.addressDetails ?? "")"
        addressView.showDirection = {
            guard let latitude  = self.booking?.latitude else { return }
            guard let longitude = self.booking?.longitude else { return }
            let url = URL(string: "maps://?saddr=&daddr=\(latitude),\(longitude)")
            if UIApplication.shared.canOpenURL(url!) {
                UIApplication.shared.open(url!, options: [:], completionHandler: nil)
            }
        }
        bookingTimeView.bookingTimeLabel.text = booking?.createdAt.toDate()?.toString(.custom("dd MMM, yyyy - hh:mm a"))

        if let notes = booking?.notes, !notes.isEmpty {
            notesView.notesLabel.text = notes
        } else {
            notesView?.removeFromSuperview()
        }
        let service = UserDefaults.standard.configs?.services.first(where: {$0.key == booking?.service.key })
        paymentSummaryView.serviceNameLabel.text = service?.name
        let unitSymbol = UserDefaults.standard.configs?.paymentSettings.currency.symbol ?? ""
        let servicePrice = Float(service?.price ?? "") ?? 0
        paymentSummaryView.servicePriceLabel.text = unitSymbol + "\(servicePrice)"
        let taxPercentage = Float(UserDefaults.standard.configs?.paymentSettings.taxPercentage ?? "") ?? 0
        paymentSummaryView.taxPercentLabel.text = "tax".localized + "(\(taxPercentage)%)"
        let totalTax = taxPercentage / 100 * servicePrice
        paymentSummaryView.taxValueLabel.text = unitSymbol + "\(totalTax)"
        paymentSummaryView.totalValueLabel.text = unitSymbol + "\(totalTax + servicePrice)"
        switch BookingStatus.init(rawValue: booking?.status.key ?? "") {
        case .some(.new):
            callCustomer.isHidden = true
            serviceStatusView.isHidden = true
            waitingCustomerApprovalLabel.isHidden = true
            setButtonTitle(title: "accept_booking")
            
        case .some(.accepted):
            servicePriceView.isHidden = true
            serviceStatusView.isHidden = false
            callCustomer.isHidden = false
            waitingCustomerApprovalLabel.isHidden = true
            setButtonTitle(title: "on_the_way")
            
        case .some(.onTheWay):
            servicePriceView.isHidden = true
            waitingCustomerApprovalLabel.isHidden = true
            setButtonTitle(title: "arrived")
            
        case .some(.arrived):
            servicePriceView.isHidden = true
            waitingCustomerApprovalLabel.isHidden = true
            setButtonTitle(title: "work_in_progress")
            
        case .some(.inProgress):
            servicePriceView.isHidden = true
            waitingCustomerApprovalLabel.isHidden = true
            setButtonTitle(title: "work_done")
            
        case .some(.pendingApproval):
            servicePriceView.isHidden = true
            button.isHidden = true
            waitingCustomerApprovalLabel.isHidden = false

        case .some(.pendingPayment):
            waitingCustomerApprovalLabel.isHidden = true
            button.isHidden = false
            setButtonTitle(title: "confirm_payment")

        case .some(.done):
            servicePriceView.isHidden = true
            callCustomer.isHidden = true
            button.isHidden = true
            waitingCustomerApprovalLabel.isHidden = true

        case .some(.reviewed):
            servicePriceView.isHidden = true
            callCustomer.isHidden = true
            button.isHidden = true
            waitingCustomerApprovalLabel.isHidden = true
            
        case .some(.canceled):
            servicePriceView.isHidden = true
            callCustomer.isHidden = true
            button.isHidden = true
            waitingCustomerApprovalLabel.isHidden = true
            
        case .none: break
        }
    }
    
    fileprivate func setButtonTitle(title: String) {
        button.setTitle(title.localized, for: .normal)
        button.setTitle(title.localized, for: .selected)
        button.setTitle(title.localized, for: .highlighted)
    }

  
    
    @IBAction func buttonTapped(_ sender: Any) {
        switch BookingStatus.init(rawValue: booking?.status.key ?? "") {
        case .some(.new):
           postData(action: "accept")

        case .some(.accepted):
            postData(action: "on-the-way")
            
        case .some(.onTheWay):
            postData(action: "arrived")
            
        case .some(.arrived):
            postData(action: "in-progress")
            
        case .some(.inProgress):
            postData(action: "work-done")
            
        case .some(.pendingApproval): break
        case .some(.pendingPayment):
            postData(action: "confirm-payment")
            
        case .some(.done): break
        case .some(.reviewed): break
        case .some(.canceled): break
        case .none: break
        }
    }
    
    
    
    @IBAction func ShowdirectionButtonIsTapped(_ sender: Any) {
        guard let latitude  = booking?.latitude else { return }
        guard let longitude = booking?.longitude else { return }
        let url = URL(string: "maps://?saddr=&daddr=\(latitude),\(longitude)")
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.open(url!, options: [:], completionHandler: nil)
        }
    }
    
}
