//
//  ProviderFirstTimeChooseCategoriesViewController.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 22/10/2021.
//

import UIKit

class ProviderFirstTimeChooseCategoriesViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.register(
                UINib(nibName: "ProviderChooseCategoriesTableViewCell", bundle: nil),
                forCellReuseIdentifier: "ProviderChooseCategoriesTableViewCell")
        }
    }
    
    @Api(method: .patch, path: .updateCategories)
    var user: User?

    var cancellable: Cancellable?

    var selectedCategories = UserDefaults.standard.user?.categories ?? []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        handleResponse()
    }

    fileprivate func presentProviderHome() {
        let mainTabBar = ProviderHomeTabBarController.instantiate(fromAppStoryboard: .ProviderHome)
        mainTabBar.modalPresentationStyle = .fullScreen
        present(mainTabBar, animated: true, completion: nil)
    }

    fileprivate func handleResponse() {
        self.cancellable = _user.$result.sink { [weak self]  res in
            self?.stopActivityIndicator()
            switch res {
            case  .success(value: let user):
                UserDefaults.standard.user = user
                self?.presentProviderHome()
            case .none: break
            case .some(.error): break
            }
        }
    }

    @IBAction func saveTapped(_ sender: Any) {
        struct UpdateCategoriesRequest: Codable { var categories: String }
        showActivityIndicator()
        _user.callApi(parameters: UpdateCategoriesRequest(categories: selectedCategories.map({$0.key.rawValue}).joined(separator: ",")))
    }
}

extension ProviderFirstTimeChooseCategoriesViewController :UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UserDefaults.standard.configs?.categories.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ProviderChooseCategoriesTableViewCell", for: indexPath) as? ProviderChooseCategoriesTableViewCell,
              let category = UserDefaults.standard.configs?.categories[indexPath.row] else {
            return UITableViewCell()
        }
        cell.categoryNameLabel.text = category.name.localized
        cell.checkboxButton.isSelected = selectedCategories.contains(where: { $0.key == category.key })
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? ProviderChooseCategoriesTableViewCell,
           let category = UserDefaults.standard.configs?.categories[indexPath.row] {
            if cell.checkboxButton.isSelected {
                cell.checkboxButton.isSelected = false
                selectedCategories.removeAll(where: { $0.key == category.key })
            } else {
                cell.checkboxButton.isSelected = true
                selectedCategories.append(category)
            }
        }
    }
}
