//
//  CustomerBookingDetailsViewController.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 10/10/2021.
//

import UIKit
import PayPalCheckout
import SwiftMessages

class CustomerBookingDetailsViewController: UIViewController {
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var bookingDetailsView: UIView!
    @IBOutlet weak var serviceNameLabel: UILabel!
    @IBOutlet weak var iconContainerView: UIView!
    @IBOutlet weak var bookingStatusView: UIView!
    @IBOutlet weak var dateTimeLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var callProviderView: CallProviderView!
    @IBOutlet weak var addressView: CustomerConfirmingAddressView!
    @IBOutlet weak var bookingTimeView: CustomerConfirmingBookingTimeView!
    @IBOutlet weak var notesView: CustomerConfirmingNotesView!
    @IBOutlet weak var paymentSummaryView: CustomerConfirmingPaymentSummary!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var secondButton: UIButton!

    @Api(method: .get, path: .bookings)
    var booking: Booking?

    @Api(method: .post, path: .orderPaypal)
    var paypalOrderResponse: PaypalOrderResponse?

    @Api(method: .post, path: .reviews)
    var reviewResponse: GenericResponse?

    let refreshControl = UIRefreshControl()
    var cancellables: [AnyCancellable] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "booking_details".localized
        handleBackendResponses()
        setupUI()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        scrollView.refreshControl = refreshControl
    }

    func configurePayPalCheckout() {
        guard let orderId = paypalOrderResponse?.id else { return }
        Checkout.start(presentingViewController: self) { createOrderAction in
            createOrderAction.set(orderId: orderId)
        } onApprove: { [weak self] approval in
            guard let bookingKey = self?.booking?.key else { return }
            self?.showActivityIndicator()
            struct PaypalCaptureRequestParameters: Codable { var booking_key, order_id: String }
            self?._booking.method = .post
            self?._booking.path = ApiURLPath.capturePaypal.rawValue
            self?._booking.callApi(parameters: PaypalCaptureRequestParameters(booking_key: bookingKey, order_id: orderId))
        }
    }

    @objc func refresh(_ sender: AnyObject) {
       fetchData()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? CustomerHomeTabBarViewController {
            tabBarVC.hideTabbar()
        }
        NotificationCenter.default.addObserver(self, selector: #selector(onDidReceiveNotification), name: Notification.Name("didReceiveNotification"), object: nil)
        loadUI()
        fetchData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(
            self,
            name: NSNotification.Name(rawValue: "didReceiveNotification"),
            object: nil)
    }

    @objc func onDidReceiveNotification() {
        fetchData()
    }

    fileprivate func fetchData() {
        guard let booking = booking else { return }
        showActivityIndicator()
        _booking.method = .get
        _booking.path = ApiURLPath.bookings.rawValue
        _booking.callApi(urlParameter: "/\(booking.key)")
    }

    fileprivate func postData(action: String) {
        guard let booking = booking else { return }
        showActivityIndicator()
        _booking.method = .post
        _booking.path = ApiURLPath.bookings.rawValue
        _booking.callApi(urlParameter: "/\(booking.key)/\(action)")
    }

    fileprivate func addReview(content: String, rating: String) {
        guard let booking = booking else { return }
        showActivityIndicator()
        struct AddReviewRequestParameters: Codable { var booking_key, rating, content: String }
        _reviewResponse.callApi(parameters: AddReviewRequestParameters(booking_key: booking.key, rating: rating, content: rating))
    }

    fileprivate func handleBackendResponses() {
        _booking.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            self?.refreshControl.endRefreshing()
            switch res {
            case .success:
                self?.loadUI()
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }.store(in: &cancellables)

        _reviewResponse.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            SwiftMessages.hideAll()
            switch res {
            case .success:
                SwiftMessageHelper.showMessage(message: self?.reviewResponse?.message ?? "")
                self?.fetchData()
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }.store(in: &cancellables)

        _paypalOrderResponse.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            switch res {
            case .success:
                SwiftMessages.hideAll()
                self?.configurePayPalCheckout()
            case .error(message: let error):
                debugPrint(error)
            case .none:
                break
            }
        }.store(in: &cancellables)
    }

    fileprivate func loadUI() {
        serviceNameLabel.text = booking?.service.name
        iconContainerView.backgroundColor = UIColor(hexString: booking?.service.color ?? "")
        iconImageView.kf.setImage(with: URL(string: booking?.service.icon ?? ""))
        bookingStatusView.backgroundColor = BookingStatus(rawValue: booking?.status.key ?? "")?.backgroundColor
        statusLabel.text = booking?.status.name
        dateTimeLabel.text = booking?.bookingAt.toDate()?.toString(.custom("dd MMM, yyyy - hh:mm a"))
        
        callProviderView.providerNameLabel.text = "\(booking?.provider?.firstName ?? "") \(booking?.provider?.lastName ?? "")"
        callProviderView.providerNumberLabel.text = booking?.provider?.phoneNumber
        callProviderView.callAction = {
            guard let number = self.booking?.provider?.phoneNumber else { return }
            if let url = URL(string: "tel://\(number)") {
                UIApplication.shared.openURL(url)
            }
        }
        addressView.addressLabel.text = "\(String(describing: booking?.addressName ?? "")) \n\(booking?.addressDetails ?? "")"
        bookingTimeView.bookingTimeLabel.text = booking?.createdAt.toDate()?.toString(.custom("dd MMM, yyyy - hh:mm a"))
        if let notes = booking?.notes, !notes.isEmpty {
            notesView.notesLabel.text = notes
            notesView.isHidden = false
        } else {

            notesView.isHidden = true
        }
        let service = UserDefaults.standard.configs?.services.first(where: {$0.key == booking?.service.key })
        paymentSummaryView.serviceNameLabel.text = service?.name
        let unitSymbol = UserDefaults.standard.configs?.paymentSettings.currency.symbol ?? ""
        let servicePrice = Float(service?.price ?? "") ?? 0
        paymentSummaryView.servicePriceLabel.text = unitSymbol + "\(servicePrice)"
        let taxPercentage = Float(UserDefaults.standard.configs?.paymentSettings.taxPercentage ?? "") ?? 0
        paymentSummaryView.taxPercentLabel.text = "tax".localized + "(\(taxPercentage)%)"
        let totalTax = taxPercentage / 100 * servicePrice
        paymentSummaryView.taxValueLabel.text = unitSymbol + "\(totalTax)"
        paymentSummaryView.totalValueLabel.text = unitSymbol + "\(totalTax + servicePrice)"

        switch BookingStatus.init(rawValue: booking?.status.key ?? "") {
        case .some(.new):
            callProviderView.isHidden = true
            setButtonTitle(title: "cancel_booking")

        case .some(.accepted):
            callProviderView.isHidden = false
            setButtonTitle(title: "cancel_booking")

        case .some(.onTheWay):
            callProviderView.isHidden = false

            setButtonTitle(title: "cancel_booking")
            
        case .some(.arrived):
            callProviderView.isHidden = false

            setButtonTitle(title: "cancel_booking")

        case .some(.inProgress):
            callProviderView.isHidden = false
            button.isHidden = true
            
        case .some(.pendingApproval):
            callProviderView.isHidden = false
            button.isHidden = false

            setButtonTitle(title: "approve_work")

        case .some(.pendingPayment):
            callProviderView.isHidden = false
            button.isHidden = false
            setButtonTitle(title: "pay")

        case .some(.done):
            callProviderView.isHidden = true
            setButtonTitle(title: "review")

            // secondButton
            secondButton.isHidden = false
            secondButton.setTitle("book_again".localized, for: .normal)
            secondButton.setTitle("book_again".localized, for: .selected)
            secondButton.setTitle("book_again".localized, for: .highlighted)

        case .some(.reviewed):
            callProviderView.isHidden = true
            setButtonTitle(title: "book_again")
            secondButton.isHidden = true

        case .some(.canceled):
            callProviderView.isHidden = true
            setButtonTitle(title: "book_again")
            
        case .none: break
        }
    }

    fileprivate func setButtonTitle(title: String) {
        button.setTitle(title.localized, for: .normal)
        button.setTitle(title.localized, for: .selected)
        button.setTitle(title.localized, for: .highlighted)
    }

    fileprivate func setupUI() {
        bookingDetailsView.layer.cornerRadius = 8
        bookingDetailsView.borderWidth = 1
        bookingDetailsView.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.08)
        iconContainerView.layer.cornerRadius = 8
        iconContainerView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
    }

    @IBAction func buttonTapped(_ sender: Any) {
        switch BookingStatus.init(rawValue: booking?.status.key ?? "") {
        case .some(.new):
            postData(action: "cancel")

        case .some(.accepted):
            postData(action: "cancel")

        case .some(.onTheWay):
            postData(action: "cancel")

        case .some(.arrived):
            postData(action: "cancel")
            
        case .some(.inProgress):
            break
            
        case .some(.pendingApproval):
            postData(action: "approve-work")

        case .some(.pendingPayment):
            guard let view = Bundle.main.loadNibNamed("\(CustomerChoosePaymentView.self)", owner: CustomerChoosePaymentView.self, options: nil)?.first as? CustomerChoosePaymentView else { return }
            view.didSelectPaymentType = { paymentOption in
                switch paymentOption {
                case .cash: break
                case .paypal:
                    guard let bookingKey = self.booking?.key else { return }
                    self.showActivityIndicator()
                    struct PaypalOrderRequestParameters: Codable { var booking_key: String }
                    self._paypalOrderResponse.callApi(parameters: PaypalOrderRequestParameters(booking_key: bookingKey))
                }
                SwiftMessages.hideAll()
            }
            var config = SwiftMessages.defaultConfig
            config.presentationStyle = .bottom
            config.dimMode = .gray(interactive: true)
            config.duration = .forever
            config.presentationContext = .window(windowLevel: .normal)
            SwiftMessages.show(config: config, view: view)

           
        case .some(.done):
            guard let view = Bundle.main.loadNibNamed("\(CustomerReviewsView.self)", owner: CustomerReviewsView.self, options: nil)?.first as? CustomerReviewsView else { return }
            view.submitAction = {
                guard view.cosmosView.rating != 0,
                      let reviewText = view.reviewField.text,
                      !reviewText.isEmpty else {
                          return
                      }
                self.addReview(content: reviewText, rating: "\(view.cosmosView.rating)")
            }
            var config = SwiftMessages.defaultConfig
            config.presentationStyle = .bottom
            config.dimMode = .gray(interactive: true)
            config.duration = .forever
            config.presentationContext = .window(windowLevel: .normal)
            SwiftMessages.show(config: config, view: view)
        case .some(.reviewed):
            bookAgainTapped()
            
        case .some(.canceled):
            bookAgainTapped()
            
        case .none: break
        }
    }

    @IBAction func secondButtonTapped(_ sender: Any) {
        bookAgainTapped()
    }

    fileprivate func bookAgainTapped() {
        let vc = ServiceDetailsViewController()
        vc.service = booking?.service
        navigationController?.pushViewController(vc, animated: true)
        let count = navigationController?.viewControllers.count ?? 2
        navigationController?.viewControllers.remove(at: count - 2)
    }
}
