//
//  CustomerReviewsView.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 25/11/2021.
//

import UIKit
import Cosmos

class CustomerReviewsView: UIView {
    @IBOutlet weak var reviewField: UITextField!
    
    var submitAction :( () -> Void)?

    lazy var cosmosView : CosmosView = {
        var view = CosmosView()
        view.settings.filledImage = UIImage(named: "RatingStar")?.withRenderingMode(.alwaysOriginal)
        view.settings.emptyImage = UIImage(named: "unRatingStar")?.withRenderingMode(.alwaysOriginal)
        view.settings.totalStars = 5
        view.settings.starSize = 15
        view.settings.starMargin = 3.3
        view.settings.fillMode = .full
       return view
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    @IBAction func submitButtonIsTapped(_ sender: Any) {
        submitAction?()
    }
}
