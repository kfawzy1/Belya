//
//  CustomerCategoryDetailsViewController.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 24/09/2021.
//

import UIKit

class CustomerCategoryDetailsViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView! {
        didSet {
            collectionView.register(UINib(nibName: "VerticalServiceCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "VerticalServiceCollectionViewCell")
        }
    }

    var services = [Service]()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = UserDefaults.standard.configs?.categories.first(
            where: { $0.key.rawValue == services.first?.categoryKey ?? ""})?.name
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? CustomerHomeTabBarViewController {
            tabBarVC.hideTabbar()
        }
    }
}

extension CustomerCategoryDetailsViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return services.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "VerticalServiceCollectionViewCell", for: indexPath) as? VerticalServiceCollectionViewCell else {
                return UICollectionViewCell()
            }
        cell.service = services[indexPath.row]
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = ServiceDetailsViewController()
        vc.service = services[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.invalidateLayout()
        return CGSize(width: collectionView.frame.width - 24, height: 112)
    }
}
