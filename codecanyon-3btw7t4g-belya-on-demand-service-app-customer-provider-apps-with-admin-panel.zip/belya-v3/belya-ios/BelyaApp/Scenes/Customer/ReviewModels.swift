//
//  ReviewModels.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 25/11/2021.
//

import Foundation
struct ReviewRequest :Codable {
    var content : String
    var rating : Float
    var booking_key : String
}

struct ReviewResponse :Codable {
    
}
