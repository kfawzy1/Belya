//
//  CustomerConfirmingBookingViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 02/10/2021.
//

import UIKit

class CustomerConfirmingBookingViewController: UIViewController {
    @IBOutlet weak var addressView: CustomerConfirmingAddressView!
    @IBOutlet weak var bookingTimeView: CustomerConfirmingBookingTimeView!
    @IBOutlet weak var notesView: CustomerConfirmingNotesView!
    @IBOutlet weak var paymentSummaryView: CustomerConfirmingPaymentSummary!
    @IBOutlet weak var stackView: UIStackView!

    @Api(method: .post, path: .bookings)
    var createBookingResponse: Booking?

    var createBookingRequest: CreateBookingRequest?
    var cancellables: [AnyCancellable] = []

    var selectedDate: Date?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "booking_details".localized
        handleApiResponse()
        loadData()
    }

    fileprivate func handleApiResponse() {
        _createBookingResponse.$result.sink { [weak self] res in
            guard let self = self else { return }
            self.stopActivityIndicator()
            switch res {
            case .success:
                DispatchQueue.main.async {
                    self.tabBarController?.selectedIndex = 2
                    self.navigationController?.popToRootViewController(animated: true)
                }
            case .error , .none: break
            }
        }.store(in: &self.cancellables)
    }
    
    fileprivate func loadData() {
        addressView.addressLabel.text = "\(String(describing: createBookingRequest?.addressName ?? "")) \n\(createBookingRequest?.addressDetails ?? "")"
        bookingTimeView.bookingTimeLabel.text = selectedDate?.toString(.custom("EEEE, dd MMM, yyyy - hh:mm a"))
        if let notes = createBookingRequest?.notes, !notes.isEmpty {
            notesView.notesLabel.text = notes
        } else {
            stackView.removeArrangedSubview(notesView)
            notesView.removeFromSuperview()
        }
        let service = UserDefaults.standard.configs?.services.first(where: {$0.key == createBookingRequest?.serviceKey})
        paymentSummaryView.serviceNameLabel.text = service?.name
        let unitSymbol = UserDefaults.standard.configs?.paymentSettings.currency.symbol ?? ""
        let servicePrice = Float(service?.price ?? "") ?? 0
        paymentSummaryView.servicePriceLabel.text = unitSymbol + "\(servicePrice)"
        let taxPercentage = Float(UserDefaults.standard.configs?.paymentSettings.taxPercentage ?? "") ?? 0
        paymentSummaryView.taxPercentLabel.text = "tax".localized + "(\(taxPercentage)%)"
        let totalTax = taxPercentage / 100 * servicePrice
        paymentSummaryView.taxValueLabel.text = unitSymbol + "\(totalTax)"
        paymentSummaryView.totalValueLabel.text = unitSymbol + "\(totalTax + servicePrice)"
    }

    func confirmBooking() {
        guard var createBookingRequest = createBookingRequest else {
            return
        }
        createBookingRequest.bookingAt = selectedDate?.toString(.custom("yyyy-MM-dd hh:mm a")) ?? ""
        self.showActivityIndicator()
        self._createBookingResponse.callApi(parameters: createBookingRequest)
    }

    @IBAction func confirmBookingTapped(_ sender: Any) {
        confirmBooking()
    }
}
