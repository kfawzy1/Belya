//
//  CreateBookingRequest.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 06/10/2021.
//

import Foundation


struct CreateBookingRequest: Codable {
    var serviceKey: String?
    var bookingAt: String?
    var notes: String?
    var longitude: String?
    var latitude: String?
    var addressName: String?
    var addressDetails: String?

    enum CodingKeys: String, CodingKey {
        case serviceKey = "service_key"
        case bookingAt = "booking_at"
        case notes
        case longitude
        case latitude
        case addressName = "address_name"
        case addressDetails = "address_details"
    }
}
