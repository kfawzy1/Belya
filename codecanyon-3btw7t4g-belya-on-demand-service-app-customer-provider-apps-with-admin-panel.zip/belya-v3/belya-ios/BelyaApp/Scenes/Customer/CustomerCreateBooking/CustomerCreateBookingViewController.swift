//
//  CustomerCreateBookingViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 01/10/2021.
//

import UIKit
import SwiftMessages

class CustomerCreateBookingViewController: UIViewController {
    @IBOutlet weak var bookingTimeView: CustomerCreateBookingTimeView!
    @IBOutlet weak var notesView: CustomerCreateBookingAddNotesView!
    var createBookingRequest: CreateBookingRequest?
    var selectedDate: Date? {
        didSet {
            let convertedDate = selectedDate?.convertToTimeZone(initTimeZone: TimeZone.init(abbreviation: "UTC")!, timeZone: TimeZone.current)
            bookingTimeView.selectedTimeLabel.text = convertedDate?.toString(.custom("EEEE, dd MMM, yyyy - hh:mm a"))
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "booking_details".localized
        configureViews()
        selectedDate = Date()
    }

    fileprivate func configureViews() {
        bookingTimeView.scheduleAction = {
            guard let view = Bundle.main.loadNibNamed("\(CustomerCreateBookingChooseTimeView.self)", owner: CustomerCreateBookingChooseTimeView.self, options: nil)?.first as? CustomerCreateBookingChooseTimeView else { return }

            view.didChooseTime = { date in
                self.selectedDate = date
                self.bookingTimeView.scheduleButton.isSelected = true
                self.bookingTimeView.nowButton.isSelected = false
                SwiftMessages.hideAll()
            }
            var config = SwiftMessages.defaultConfig
            config.presentationStyle = .bottom
            config.dimMode = .gray(interactive: true)
            config.duration = .forever
            config.presentationContext = .window(windowLevel: .normal)
            SwiftMessages.show(config: config, view: view)
        }

        bookingTimeView.nowAction = {
            self.selectedDate = Date()
            self.bookingTimeView.scheduleButton.isSelected = false
            self.bookingTimeView.nowButton.isSelected = true
        }
    }

    @IBAction func nextTapped(_ sender: Any) {
        //TODO: add address
        let selectedAddress = UserDefaults.standard.selectedAddress
        createBookingRequest?.addressName = selectedAddress?.name
        createBookingRequest?.addressDetails = selectedAddress?.formattedAddress
        createBookingRequest?.longitude = "\(String(describing: selectedAddress?.longitude))"
        createBookingRequest?.latitude = "\(String(describing: selectedAddress?.latitude))"
        createBookingRequest?.notes = notesView.notesTextView.text ?? ""
        let vc = CustomerConfirmingBookingViewController()
        let convertedDate = selectedDate?.convertToTimeZone(initTimeZone: TimeZone.init(abbreviation: "UTC")!, timeZone: TimeZone.current)
        vc.selectedDate = convertedDate
        vc.createBookingRequest = createBookingRequest
        navigationController?.pushViewController(vc, animated: true)
    }
}
