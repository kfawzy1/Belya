//
//  CustomerHomeTabBarViewController.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 17/09/2021.
//

import UIKit

class CustomerHomeTabBarViewController: UITabBarController {

    func hideTabbar() {
        tabBar.isHidden = true
    }

    func showTabBar() {
        tabBar.isHidden = false
    }
}
