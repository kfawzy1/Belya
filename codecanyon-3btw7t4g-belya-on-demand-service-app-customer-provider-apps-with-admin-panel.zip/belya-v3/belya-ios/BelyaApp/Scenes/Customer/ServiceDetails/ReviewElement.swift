//
//  ReviewElement.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 28/09/2021.
//

import Foundation

struct ReviewsResponse: Codable {
    let data: [ReviewElement]
    let prevCursor, nextCursor: String?
}

// MARK: - ReviewElement
struct ReviewElement: Codable {
    let key, content, rating: String
    let user: ReviewUser
    let createdAt: String
}

// MARK: - User
struct ReviewUser: Codable {
    let firstName: String
    let lastName: String
    let email: String
    let phoneNumber: String
    let categories: [Category]
}
