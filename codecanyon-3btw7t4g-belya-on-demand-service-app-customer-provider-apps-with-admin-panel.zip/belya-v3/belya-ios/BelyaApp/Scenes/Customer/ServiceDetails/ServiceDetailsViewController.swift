//
//  ServiceDetailsViewController.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 24/09/2021.
//

import UIKit

class ServiceDetailsViewController: UIViewController {
    @IBOutlet weak var indicatorView: BaseActivityIndicator!
    @IBOutlet weak var reviewsTableView: UITableView! {
        didSet {
            reviewsTableView.register(
                UINib(nibName: "ReviewsTableViewCell", bundle: nil),
                forCellReuseIdentifier: "ReviewsTableViewCell")
        }
    }

    @IBOutlet weak var iconContainerView: UIView!
    @IBOutlet weak var serviceDetailsView: UIView!
    @IBOutlet weak var serviceNameLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var reviewsCountLabel: UILabel!
    @IBOutlet weak var priceDurationLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var reviewsContainerView: UIView!
    @IBOutlet weak var reviewsTableViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var iconImageView: UIImageView!

    let recentAddressVC = RecentAddressesController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCornerRadius()
        fetchReviews()
        loadData()
        addObserver()
        if let tabBarVC = tabBarController as? CustomerHomeTabBarViewController {
            tabBarVC.hideTabbar()
        }
    }

    let keyPathValue = "contentSize"

    var service: Service?

    @Api(method: .get, path: .reviews)
    var reviewsResponse: ReviewsResponse?

    var cancellable: Cancellable?

    fileprivate func fetchReviews() {
        self.cancellable = _reviewsResponse.$result.sink { [weak self] res in
            self?.indicatorView.stopAnimating()
            switch res {
            case .success:
                self?.reviewsTableView.isHidden = false
                self?.reviewsTableView.reloadData()
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }
        indicatorView.startAnimating()
        _reviewsResponse.callApi(urlParameter: "/\(service?.key ?? "")")
    }
    
    fileprivate func addObserver() {
        reviewsTableView.addObserver(self,
                                       forKeyPath: keyPathValue,
                                       options: NSKeyValueObservingOptions.new, context: nil)

    }

    fileprivate func setupCornerRadius() {
        serviceDetailsView.layer.cornerRadius = 8
        serviceDetailsView.borderWidth = 1
        serviceDetailsView.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.08)

        descriptionView.layer.cornerRadius = 8
        descriptionView.borderWidth = 1
        descriptionView.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.08)

        reviewsContainerView.layer.cornerRadius = 8
        reviewsContainerView.borderWidth = 1
        reviewsContainerView.borderColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.08)

        iconContainerView.layer.cornerRadius = 8
        iconContainerView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMaxXMaxYCorner]
    }

    fileprivate func loadData() {
        guard let service = service else { return }
        title = service.name
        serviceNameLabel.text = service.name
        ratingLabel.text = service.rating
        reviewsCountLabel.text = "(\(service.reviewsCount))"
        let unitSymbol = UserDefaults.standard.configs?.paymentSettings.currency.symbol ?? ""

        priceDurationLabel.text = "\(unitSymbol)\(Int(Double(service.price ) ?? 0)) - \(service.duration) min"
        descriptionLabel.text = service.serviceDescription
        
        iconContainerView.backgroundColor = UIColor(hexString: service.color)
        iconImageView.kf.setImage(with: URL(string: service.icon))
    }

    //Mark: observer methods
    override func observeValue(forKeyPath keyPath: String?,
                               of object: Any?,
                               change: [NSKeyValueChangeKey : Any]?,
                               context: UnsafeMutableRawPointer?) {
        if object as? UITableView != nil,
            keyPath?.elementsEqual(keyPathValue) ?? false {
            if reviewsTableView.contentSize.height > 0 {
                reviewsTableViewHeightConstraint.constant = reviewsTableView.contentSize.height
            }
        }
    }
    
    @IBAction func bookServiceTapped(_ sender: Any) {
        if UserDefaults.standard.selectedAddress != nil {
            openCreateBookingDetails()
        } else {
            recentAddressVC.addressSelected = { selectedAddress in
                self.openCreateBookingDetails()
            }
            navigationController?.pushViewController(recentAddressVC, animated: true)
        }
    }
}

extension ServiceDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reviewsResponse?.data.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ReviewsTableViewCell") as? ReviewsTableViewCell else { return UITableViewCell() }
        cell.review = reviewsResponse?.data[indexPath.row]
        return cell
    }
}

//MARK:- open booking details
extension ServiceDetailsViewController {
    func openCreateBookingDetails() {
        let vc = CustomerCreateBookingViewController()
        vc.createBookingRequest = CreateBookingRequest(serviceKey: service?.key)
        navigationController?.pushViewController(vc, animated: true)
    }
}
