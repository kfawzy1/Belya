//
//  ChooseAddressManager.swift
//  BelyaApp
//
//  Created by Ahmed Hamdy on 30/10/2021.
//

import GooglePlaces

class ChooseAddressManager: NSObject {

    static let shared = ChooseAddressManager()
    private var currentView: UIViewController?
    var addressUpdated: ((AddressModel) -> Void)?

    private override init() {}

    func openPlacesSearchController(view: UIViewController) {
        currentView = view
        let autocompleteController = GMSAutocompleteViewController()
        autocompleteController.modalPresentationStyle = .fullScreen
        autocompleteController.delegate = self
        let fields: GMSPlaceField = GMSPlaceField(rawValue: UInt(GMSPlaceField.name.rawValue) |
                                                  UInt(GMSPlaceField.coordinate.rawValue) |
                                                  UInt(GMSPlaceField.formattedAddress.rawValue))
        autocompleteController.placeFields = fields
        // Specify a filter.
        let filter = GMSAutocompleteFilter()
        filter.type = .address
        autocompleteController.autocompleteFilter = filter
        view.present(autocompleteController, animated: true, completion: nil)
    }
}

extension ChooseAddressManager: GMSAutocompleteViewControllerDelegate {

    // Handle the user's selection.
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        saveAddress(place: place)
        currentView?.dismiss(animated: true, completion: nil)
        currentView = nil
        addressUpdated = nil
    }

    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        print("Google places Error: ", error.localizedDescription)
    }

    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        currentView?.dismiss(animated: true, completion: nil)
    }
}


//MARK:- handle saving the address and update UI
extension ChooseAddressManager {
    func saveAddress(place: GMSPlace) {
        if let name = place.name {
            let addressModel = AddressModel(name: name,
                                            formattedAddress: place.formattedAddress,
                                            latitude: place.coordinate.latitude,
                                            longitude: place.coordinate.longitude)
            addressUpdated?(addressModel)
//            UserDefaults.standard.selectedAddress = addressModel
        }
    }
}

