//
//  CustomerMenuViewController.swift
//  BelyaApp
//
//  Created by Omayma Marouf on 06/10/2021.
//

import UIKit

struct CustomerMenu {
    var title : String
    var image : UIImage?
}

class CustomerMenuViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView! {
        didSet {
            collectionView.register(UINib(nibName: "CustomerMenuCollectionViewCell", bundle: .main), forCellWithReuseIdentifier: "CustomerMenuCollectionViewCell")
        }
    }

    let data = [
        CustomerMenu(title: "profile", image: UIImage(named: "profile")),
        CustomerMenu(title: "settings", image: UIImage(named: "setting")),
        CustomerMenu(title: "about", image: UIImage(named: "about")),
        CustomerMenu(title: "support", image: UIImage(named: "support")),
        CustomerMenu(title: "sign_up_as_provider", image: UIImage(named: "signupasprovider")),
        CustomerMenu(title: "logout", image: UIImage(named: "logout"))]
}

extension CustomerMenuViewController: UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "CustomerMenuCollectionViewCell", for: indexPath) as? CustomerMenuCollectionViewCell else {
                return UICollectionViewCell()
            }
        cell.menuLabel.text = data[indexPath.row].title.localized
        cell.menuImage.image = data[indexPath.row].image
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.invalidateLayout()
        return CGSize(width: (collectionView.frame.width / 2) - 32, height: 78)
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let tabBarVC = tabBarController as? CustomerHomeTabBarViewController
        switch indexPath.row {
        case 0:
            //profile
            let profileVC = ProfileViewController()
            navigationController?.pushViewController(profileVC, animated: true)
            tabBarVC?.hideTabbar()
        case 1:
            //settings
            let settingsVC = SettingsViewController()
            navigationController?.pushViewController(settingsVC, animated: true)
            tabBarVC?.hideTabbar()
        case 2:
            //About
            let aboutVC = AboutViewController()
            navigationController?.pushViewController(aboutVC, animated: true)
            tabBarVC?.hideTabbar()
        case 3:
            //support
            let contactVC = ContactSupportViewController()
            contactVC.modalPresentationStyle = .overCurrentContext
            self.tabBarController?.present(contactVC, animated: true, completion: nil)
        case 4:
            //sign up as provider
            break
        case 5:
            //logout
            let logoutVC = LogoutViewController()
            logoutVC.modalPresentationStyle = .overCurrentContext
            self.tabBarController?.present(logoutVC, animated: true, completion: nil)
        default:
            break
        }
    }
}


//MARK:- tabbar handling
extension CustomerMenuViewController {
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? CustomerHomeTabBarViewController {
            tabBarVC.showTabBar()
        }
    }
}
