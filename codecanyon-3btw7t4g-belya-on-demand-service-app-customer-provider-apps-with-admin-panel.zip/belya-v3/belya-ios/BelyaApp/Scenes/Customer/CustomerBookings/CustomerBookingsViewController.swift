//
//  CustomerBookingsViewController.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 09/10/2021.
//

import UIKit

class CustomerBookingsViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var collectionView: UICollectionView! {
        didSet {
            collectionView.register(UINib(nibName: "BookingsListCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "BookingsListCollectionViewCell")
        }
    }

    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var noBookingsView: UIStackView!
    
    @Api(method: .get, path: .bookings)
    var bookingResponse: BookingResponse?

    var cancellable: Cancellable?
    let cellHeight: CGFloat = 112
    let emtpyViewHeight: CGFloat = 400
    let cellMargin: CGFloat = 16

    override func viewDidLoad() {
        super.viewDidLoad()
        handleBookingsResponse()
        RefreshUtils.addPullToRefresh(controller: self, scrollView: scrollView, refreshAction: #selector(refresh))
     }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? CustomerHomeTabBarViewController {
            tabBarVC.showTabBar()
        }
        fetchData()
    }

    @objc func refresh() {
        scrollView.refreshControl?.endRefreshing()
        fetchData()
    }

    fileprivate func fetchData() {
        showActivityIndicator()
        _bookingResponse.callApi()
    }
    
    fileprivate func handleBookingsResponse() {
        self.cancellable = _bookingResponse.$result.sink { [weak self] res in
            self?.stopActivityIndicator()
            switch res {
            case .success(value: let bookingResponse):
                if bookingResponse.data.isEmpty {
                    self?.collectionView.isHidden = true
                    self?.noBookingsView.isHidden = false
                } else {
                    self?.collectionView.reloadData()
                }
                self?.updateViewHeight()
            case .error(message: let error):
                print(error)
            case .none:
                break
            }
        }
    }
}

extension CustomerBookingsViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bookingResponse?.data.count ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "BookingsListCollectionViewCell", for: indexPath) as? BookingsListCollectionViewCell else {
                return UICollectionViewCell()
            }
        cell.booking = bookingResponse?.data[indexPath.row]
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = CustomerBookingDetailsViewController()
        vc.booking = bookingResponse?.data[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.invalidateLayout()
        return CGSize(width: collectionView.frame.width - 24, height: cellHeight)
    }
}


//MARK:- handle view height
extension CustomerBookingsViewController {
    func updateViewHeight() {
        guard let list = bookingResponse?.data else { return }
        if list.count == 0 {
            collectionViewHeight.constant = emtpyViewHeight
        } else {
            collectionViewHeight.constant = CGFloat(list.count) * (cellHeight + cellMargin)
        }
    }
}

//MARK:- booking status
enum BookingStatus: String {
    case new
    case accepted
    case onTheWay = "on_the_way"
    case arrived
    case inProgress = "in_progress"
    case pendingApproval = "pending_approval"
    case pendingPayment = "pending_payment"
    case done
    case reviewed
    case canceled

    var backgroundColor: UIColor {
        switch self {
        case .new:
            return UIColor(named: "yellow400") ?? .yellow
        case .accepted:
            return UIColor(named: "orange400") ?? .orange
        case .onTheWay:
            return UIColor(named: "brown400") ?? .brown
        case .arrived:
            return UIColor(named: "blue400") ?? .blue
        case .inProgress:
            return UIColor(named: "purple400") ?? .blue
        case .pendingApproval:
            return UIColor(named: "cobalt400") ?? .yellow
        case .pendingPayment:
            return UIColor(named: "platinum400") ?? .yellow
        case .done:
            return UIColor(named: "green400") ?? .green
        case .reviewed:
            return UIColor(named: "green400") ?? .green
        case .canceled:
            return UIColor(named: "red400") ?? .red
        }
    }
}
