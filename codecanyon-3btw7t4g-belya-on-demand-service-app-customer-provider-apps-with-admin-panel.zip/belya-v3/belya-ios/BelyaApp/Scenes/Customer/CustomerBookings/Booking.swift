//
//  Booking.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 06/10/2021.
//

import Foundation

struct BookingResponse: Codable {
    let data: [Booking]
    let prevCursor, nextCursor: String?
}

// MARK: - Booking
struct Booking: Codable {
    let key: String
    let customer: User?
    let provider: User?
    let service: Service
    let status: Status
    let bookingAt, latitude, longitude: String
    let notes: String?
    let addressName, addressDetails: String
   // let tax, total: float
    let createdAt: String
}
