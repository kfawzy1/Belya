//
//  CustomerChoosePaymentView.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 24/11/2021.
//

import UIKit

class CustomerChoosePaymentView: UIView {
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.register(UINib(nibName: "PaymentTypeTableViewCell", bundle: nil),
                                    forCellReuseIdentifier: "PaymentTypeTableViewCell")
        }
    }

    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!

    let keyPathValue = "contentSize"
    var data: [PaymentOption] = [.cash, .paypal]

    var didSelectPaymentType: ((PaymentOption) -> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        tableView.delegate = self
        tableView.dataSource = self
        addObserver()
        tableView.reloadData()
    }

    fileprivate func addObserver() {
        tableView.addObserver(self, forKeyPath: keyPathValue,
                              options: NSKeyValueObservingOptions.new, context: nil)
    }

    override func observeValue(forKeyPath keyPath: String?,
                               of object: Any?,
                               change: [NSKeyValueChangeKey : Any]?,
                               context: UnsafeMutableRawPointer?) {
        if object as? UITableView != nil,
            keyPath?.elementsEqual(keyPathValue) ?? false {
            if tableView.contentSize.height > 0 {
                tableViewHeight.constant = tableView.contentSize.height
            }
        }
    }
}

extension CustomerChoosePaymentView: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PaymentTypeTableViewCell") as? PaymentTypeTableViewCell else {
            return UITableViewCell()
        }
        cell.titleLabel.text = data[indexPath.row].title.localized
        cell.iconImageView.image = data[indexPath.row].image
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        didSelectPaymentType?(data[indexPath.row])
    }
}

enum PaymentOption {
    case cash
    case paypal
    
    var title : String {
        switch self {
        case .cash:
            return "Cash"
        case .paypal:
            return "Paypal"
        }
    }

    var image : UIImage {
        switch self{
        case .cash:
            return UIImage(named: "cashIcon") ?? UIImage()
        case .paypal:
            return UIImage(named: "PaypalIcon") ?? UIImage()
        }
    }
}
