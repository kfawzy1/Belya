//
//  CustomerHomeViewController.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 19/09/2021.
//

import UIKit
import GooglePlaces

class CustomerHomeViewController: UIViewController {
    @IBOutlet weak var categoriesCollectionView: UICollectionView! {
        didSet {
            categoriesCollectionView.register(
                UINib(nibName: "CategoryCollectionViewCell", bundle: nil),
                forCellWithReuseIdentifier: "CategoryCollectionViewCell")
        }
    }

    @IBOutlet weak var popularServicesCollectionView: UICollectionView! {
        didSet {
            registerServiceCell(collectionView: popularServicesCollectionView)
        }
    }

    @IBOutlet weak var recommendedServicesCollectionView: UICollectionView! {
        didSet {
            registerServiceCell(collectionView: recommendedServicesCollectionView)
        }
    }

    @IBOutlet weak var plumbersCollectionView: UICollectionView! {
        didSet {
            registerServiceCell(collectionView: plumbersCollectionView)
        }
    }

    @IBOutlet weak var chooseAddressLabel: UILabel!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var plumbersTitleLabel: UILabel!
    @IBOutlet weak var carpentersTitleLabel: UILabel!

    @IBOutlet weak var carpentersCollectionView: UICollectionView! {
        didSet {
            registerServiceCell(collectionView: carpentersCollectionView)
        }
    }

    fileprivate func registerServiceCell(collectionView: UICollectionView) {
        collectionView.register(
            UINib(nibName: "HorizontalServiceCollectionViewCell", bundle: nil),
            forCellWithReuseIdentifier: "HorizontalServiceCollectionViewCell")
    }

    let plumbers = UserDefaults.standard.configs?.services.filter( {$0.categoryKey == CategoryKey.plumbers.rawValue})
    let carpenters = UserDefaults.standard.configs?.services.filter( {$0.categoryKey == CategoryKey.carpenters.rawValue})
    let popularServices = UserDefaults.standard.configs?.services.sorted(by: {$0.bookingsCount > $1.bookingsCount})
    let recommendedServices = UserDefaults.standard.configs?.services.sorted(by: { Float($0.rating) ?? 0 > Float($1.rating) ?? 0 })

    override func viewDidLoad() {
        super.viewDidLoad()
        updateSectionsHeader()
        handleSearchAction()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let tabBarVC = tabBarController as? CustomerHomeTabBarViewController {
            tabBarVC.showTabBar()
        }
        updateAddress()
    }

    @IBAction func chooseAddressTapped(_ sender: Any) {
        let recentAddressVC = RecentAddressesController()
        navigationController?.pushViewController(recentAddressVC, animated: true)
    }
}

extension CustomerHomeViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView {
        case categoriesCollectionView, popularServicesCollectionView, recommendedServicesCollectionView:
            return 5

        case plumbersCollectionView:
            return plumbers?.count ?? 0

        case carpentersCollectionView:
            return carpenters?.count ?? 0

        default:
            return 0
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == categoriesCollectionView {
            guard let cell = collectionView.dequeueReusableCell(
                withReuseIdentifier: "CategoryCollectionViewCell", for: indexPath) as? CategoryCollectionViewCell else {
                    return UICollectionViewCell()
                }
            let categories = UserDefaults.standard.configs?.categories
            cell.category = categories?[indexPath.row]
            return cell
        } else {
            guard let cell = collectionView.dequeueReusableCell(
                withReuseIdentifier: "HorizontalServiceCollectionViewCell", for: indexPath) as? HorizontalServiceCollectionViewCell else {
                    return UICollectionViewCell()
                }
            switch collectionView {
            case popularServicesCollectionView:
                cell.service = popularServices?[indexPath.row]
            case recommendedServicesCollectionView:
                cell.service = recommendedServices?[indexPath.row]
            case plumbersCollectionView:
                cell.service = plumbers?[indexPath.row]
            case carpentersCollectionView:
                cell.service = carpenters?[indexPath.row]
            default:
                return UICollectionViewCell()
            }
            return cell
        }
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == categoriesCollectionView {
            let vc = CustomerCategoryDetailsViewController()
            if let services = UserDefaults.standard.configs?.services.filter({ $0.categoryKey == UserDefaults.standard.configs?.categories[indexPath.row].key.rawValue }) {
                vc.services = services
            }
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let vc = ServiceDetailsViewController()
            switch collectionView {
            case popularServicesCollectionView:
                vc.service = popularServices?[indexPath.row]
            case recommendedServicesCollectionView:
                vc.service = recommendedServices?[indexPath.row]
            case plumbersCollectionView:
                vc.service = plumbers?[indexPath.row]
            case carpentersCollectionView:
                vc.service = carpenters?[indexPath.row]
            default: break
            }
            navigationController?.pushViewController(vc, animated: true)
        }
    }
}
//MARK:- search action
extension CustomerHomeViewController {
    func handleSearchAction() {
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(searchTapped))
        searchView.addGestureRecognizer(tapGesture)
    }

    @objc func searchTapped() {
        tabBarController?.selectedIndex = 1
    }
}

//MARK:- update address
extension CustomerHomeViewController {
    func updateAddress() {
        if let savedAddress = UserDefaults.standard.selectedAddress {
            chooseAddressLabel.text = savedAddress.name
        }
    }
}


//MARK:- handle section headers
extension CustomerHomeViewController {
    func updateSectionsHeader() {
        plumbersTitleLabel.text = UserDefaults.standard.configs?.categories.first(where: {$0.key == CategoryKey.plumbers})?.name

        carpentersTitleLabel.text = UserDefaults.standard.configs?.categories.first(where: {$0.key == CategoryKey.carpenters})?.name
    }
}
