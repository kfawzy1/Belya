//
//  ApiURLPath.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 09/09/2021.
//

import Foundation

enum ApiURLPath: String {
    // auth
    case login = "auth/login"
    case logout = "auth/logout"
    case register = "auth/register"
    
    // config
    case configs = "configs"
    
    // Reviews
    case reviews = "reviews"
    
    // Bookings
    case bookings = "bookings"
    case bookingLeads = "bookings/leads"

    // Update categories
    case updateCategories = "users/categories"
    
    //update profile
    case updateProfile = "users"
    
    //update token
    case registerFcmToken = "users/register-fcm-token"
    
    // payment
    case orderPaypal = "payment/paypal/order"
    case capturePaypal = "payment/paypal/capture"
}
