//
//  ApiResponse.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 09/09/2021.
//

import Foundation

struct BelyaErrorResponse: Codable {
    var message: String?
}
