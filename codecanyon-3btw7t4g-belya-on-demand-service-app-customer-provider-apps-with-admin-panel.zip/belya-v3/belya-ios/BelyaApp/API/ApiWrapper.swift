//
//  ApiWrapper.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 08/09/2021.
//

import Foundation
import Moya
import Combine

typealias Cancellable = Combine.Cancellable
typealias AnyCancellable = Combine.AnyCancellable

typealias URLEncoding = Moya.URLEncoding
typealias JsonEncoding = Moya.JSONEncoding

let genericErrorMethod = "Something went wrong."

@propertyWrapper
class Api<T: Codable>: ObservableObject {
    var wrappedValue: T?
    let provider = MoyaProvider<BelyaTarget>()
    var method: Moya.Method
    var path: String
    var encoding: Moya.ParameterEncoding?

    @Published private(set) var result: Result<T>! {
        willSet {
            switch newValue {
            case .success(let res):
                self.wrappedValue = res
            case .error(message: let message, statusCode: _, showError: let showError):
                guard showError else { return }
                SwiftMessageHelper.showMessage(theme: .error, message: message)
            default:
                break
            }
        }
    }

    init(method: Moya.Method, path: ApiURLPath, encoding: ParameterEncoding? = JsonEncoding.default, initialValue: T? = nil) {
        self.method = method
        self.path = path.rawValue
        self.encoding = encoding
        self.wrappedValue = initialValue
    }

    func callApi(parameters: Codable? = nil, urlParameter: String = "", showError: Bool = true) {
        var task: Task
        if let encoding = self.encoding, let parameters = parameters{
                task = .requestParameters(
                parameters: parameters.dictionary ?? [:],
                encoding: encoding)
            
        } else {
            task = .requestPlain
        }

        let target = BelyaTarget(path: path + urlParameter, method: method, task: task)

        provider.request(target) { result in
            switch result {
            case .success(let res):
                do {
                    if (200...300).contains(res.statusCode) {
                        let response = try JSONDecoder().decode(T.self, from: res.data)
                        self.result = .success(value: response)
                    } else {
                        let response = try JSONDecoder().decode(BelyaErrorResponse.self, from: res.data)
                        if let message = response.message, !message.isEmpty {
                            self.result = .error(message: message, statusCode: res.statusCode, showError: showError)
                        } else {
                            self.result = .error(message: genericErrorMethod, statusCode: res.statusCode, showError: showError)
                        }
                    }
                } catch {
                    debugPrint(error)
                    self.result = .error(message: error.localizedDescription, statusCode: res.statusCode, showError: showError)
                }
            case .failure(let error):
                debugPrint(error)
                self.result = .error(message: error.localizedDescription, statusCode: 500, showError: showError)
            }
        }
    }
}
