//
//  Result.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 09/09/2021.
//

import Foundation

enum Result<T> {
    case success(value: T)
    case error(message: String, statusCode: Int?, showError: Bool = true)
}
