//
//  TargetType.swift
//  BelyaApp
//
//  Created by Hussein Kishk on 09/09/2021.
//

import Moya

struct BelyaTarget: TargetType {
    var path: String

    var method: Moya.Method

    var task: Task

    var headers: [String : String]? {
        var headers = [
            "Content-Type": "application/json",
            "User-Role": UserDefaults.standard.appTarget == .Belya ? "customer" : "provider"]
        if let token = UserDefaults.standard.token {
            headers["Authorization"] = "Bearer \(token)"
        }
        return headers
    }
}

extension TargetType {
    var serverUrlString: String {
        get {
            return "YOUR_BASE_URL"
        }
    }

    var baseURL: URL {
        // pass Language here if needed
        return URL(string: "\(serverUrlString)")!
    }
}
